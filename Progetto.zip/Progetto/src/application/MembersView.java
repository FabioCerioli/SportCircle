package application;

import java.util.List;

import SportCircle.Administrator;
import SportCircle.Associate;
import SportCircle.MemberStatus;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * Manages the User Interface for viewing and managing club members.
 *
 * 
 *
 * <p>This class provides two main views:</p>
 * <ul>
 * <li><b>Member Directory (Read-Only/Interactive):</b> A searchable grid of member cards available to all users.</li>
 * <li><b>Management Dashboard (Admin Only):</b> An advanced view allowing Administrators to add, edit, lock, promote, or delete members.</li>
 * </ul>
 *
 * <p>It handles dynamic filtering (by name, email, status) and renders user cards using a responsive {@link FlowPane} layout.</p>
 */
public class MembersView {

    /**
     * Renders the general "Members" directory view accessible to all users.
     *
     * <p>This view displays a grid of cards representing {@link Associate} members.
     * It includes a filter bar at the top to search by name, email, or membership status.</p>
     *
     * @param uiUtils        Utility class for UI styling and common components.
     * @param contentArea    The main VBox container where the view is rendered.
     * @param scrollPane     The ScrollPane wrapping the content area.
     * @param homeView       Reference to HomeView for navigation.
     * @param membersView    Reference to this MembersView.
     * @param activitiesView Reference to ActivitiesView for navigation.
     * @param profileView    Reference to ProfileView for navigation.
     * @param associate      The currently logged-in user.
     * @param isAdmin        Flag indicating if the current user is an administrator.
     */
    public void showMembers(UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane,
                            HomeView homeView, MembersView membersView,
                            ActivitiesView activitiesView, ProfileView profileView,
                            Associate associate, Boolean isAdmin) {

        contentArea.getChildren().clear();

        Label title = new Label("👥 Members");
        title.setFont(new Font("Segoe UI Semibold", 26));
        title.setTextFill(Color.web("#0083b0"));
        contentArea.getChildren().add(title);

        TextField nameFilter = new TextField();
        nameFilter.setPromptText("🔍 Search name");
        nameFilter.setStyle(uiUtils.textFieldStyle);

        TextField emailFilter = new TextField();
        emailFilter.setPromptText("📧 Search email");
        emailFilter.setStyle(uiUtils.textFieldStyle);

        ComboBox<String> statusFilter = new ComboBox<>();
        statusFilter.getItems().add("All Status");
        for (MemberStatus s : MemberStatus.values()) {
            statusFilter.getItems().add(s.name());
        }
        statusFilter.getSelectionModel().select("All Status");
        statusFilter.setStyle(uiUtils.comboBoxStyle);

        Button applyBtn = new Button("Filter");
        applyBtn.setStyle(uiUtils.primaryButtonStyle);

        applyBtn.setOnMouseEntered(_ -> applyBtn.setStyle("""
                -fx-background-color: linear-gradient(to right, #29c8ea, #0096c7);
                -fx-text-fill: white;
                -fx-background-radius: 12;
                -fx-padding: 8 22;
                -fx-font-size: 14px;
                -fx-font-weight: bold;
            """));

        applyBtn.setOnMouseExited(_ -> applyBtn.setStyle("""
                -fx-background-color: linear-gradient(to right, #00b4db, #0083b0);
                -fx-text-fill: white;
                -fx-background-radius: 12;
                -fx-padding: 8 22;
                -fx-font-size: 14px;
                -fx-font-weight: bold;
            """));

        HBox filterBar = new HBox(18, nameFilter, emailFilter, statusFilter, applyBtn);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        filterBar.setPadding(new Insets(12, 0, 16, 0));

        contentArea.getChildren().add(filterBar);

        FlowPane flowPane = new FlowPane();
        flowPane.setHgap(15);
        flowPane.setVgap(15);
        flowPane.setPadding(new Insets(20, 0, 0, 0));
        flowPane.setAlignment(Pos.TOP_CENTER);

        Runnable renderMembers = () -> {
            flowPane.getChildren().clear();

            String nameQ = nameFilter.getText().trim().toLowerCase();
            String emailQ = emailFilter.getText().trim().toLowerCase();
            String statusQ = statusFilter.getValue();

            List<Associate> filtered = Database.associates.stream()
                    .filter(a -> nameQ.isEmpty() || a.getCompleteName().toLowerCase().contains(nameQ))
                    .filter(a -> emailQ.isEmpty() || a.getEmailAddress().toLowerCase().contains(emailQ))
                    .filter(a -> statusQ.equals("All Status") || a.getStatus().toString().equalsIgnoreCase(statusQ))
                    .toList();

            for (Associate m : filtered) {

                double cardWidth = 280;

                VBox card = new VBox(6);
                card.setAlignment(Pos.CENTER_LEFT);
                card.setPadding(new Insets(18));
                card.setPrefWidth(cardWidth);
                card.setMaxWidth(cardWidth);
                card.setStyle("""
                        -fx-background-color: white;
                        -fx-background-radius: 14;
                        -fx-border-color: #b3e5fc;
                        -fx-border-width: 1;
                        -fx-border-radius: 14;
                        -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 10, 0.15, 0, 2);
                    """);

                card.setOnMouseEntered(_ -> card.setStyle("""
                        -fx-background-color: #e1f5fe;
                        -fx-background-radius: 14;
                        -fx-border-color: #81d4fa;
                        -fx-border-width: 1;
                        -fx-border-radius: 14;
                        -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.25), 12, 0.20, 0, 3);
                    """));

                card.setOnMouseExited(_ -> card.setStyle("""
                        -fx-background-color: white;
                        -fx-background-radius: 14;
                        -fx-border-color: #b3e5fc;
                        -fx-border-width: 1;
                        -fx-border-radius: 14;
                        -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 10, 0.15, 0, 2);
                    """));

                Label icon = new Label("👤");
                icon.setFont(new Font(30));

                Label nameLabel = new Label(m.getCompleteName());
                nameLabel.setFont(new Font("Segoe UI Semibold", 18));
                nameLabel.setTextFill(Color.web("#01579b"));
                nameLabel.setWrapText(true);

                Label emailLabel = new Label("📧 " + m.getEmailAddress());
                emailLabel.setFont(new Font("Segoe UI", 13));
                emailLabel.setTextFill(Color.web("#444"));
                emailLabel.setWrapText(true);

                Label status = new Label("Status: " + m.getStatus());
                status.setFont(new Font("Segoe UI", 12));
                status.setPadding(new Insets(4, 8, 4, 8));

                String bgColor = uiUtils.getStatusColor(m.getStatus());
                status.setStyle("-fx-background-color: " + bgColor + "; -fx-background-radius: 8; -fx-font-weight: bold;");

                card.getChildren().addAll(icon, nameLabel, emailLabel, status);
                flowPane.getChildren().add(card);
            }
        };

        renderMembers.run();

        applyBtn.setOnAction(_ -> renderMembers.run());

        flowPane.prefWrapLengthProperty().bind(scrollPane.widthProperty().subtract(40));

        contentArea.getChildren().add(flowPane);
        scrollPane.setContent(contentArea);
    }

    /**
     * Renders the administrative interface for managing all members (Associates and Administrators).
     *
     * <p>This view is restricted to Admins and provides functionalities to:</p>
     * <ul>
     * <li>Filter members by status, name, or email.</li>
     * <li>View separated lists for Associates and Administrators.</li>
     * <li>Add new members via specific "Add" cards.</li>
     * <li>Access edit/delete/promote/lock actions on individual cards.</li>
     * </ul>
     *
     * @param uiUtils        UI utility class.
     * @param contentArea    The main content area to update.
     * @param scrollPane     The parent scroll pane.
     * @param homeView       HomeView reference.
     * @param membersView    MembersView reference.
     * @param activitiesView ActivitiesView reference.
     * @param profileView    ProfileView reference.
     * @param associate      The currently logged-in admin.
     * @param isAdmin        Must be true to access this view.
     */
    public void showManageMembers(UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane, HomeView homeView,
                                  MembersView membersView, ActivitiesView activitiesView, ProfileView profileView, Associate associate,
                                  Boolean isAdmin) {

        contentArea.getChildren().clear();

        Label title = new Label("👑 Manage Members");
        title.setFont(new Font("Segoe UI Semibold", 22));
        title.setTextFill(Color.web("#0083b0"));

        ComboBox<String> statusFilter = new ComboBox<>();
        statusFilter.getItems().add("All Status");
        for (MemberStatus s : MemberStatus.values()) {
            statusFilter.getItems().add(s.name().substring(0, 1) + s.name().substring(1).toLowerCase());
        }
        statusFilter.getSelectionModel().select("All Status");
        statusFilter.setStyle(uiUtils.comboBoxStyle);
        TextField nameFilter = new TextField();
        nameFilter.setPromptText("🔍 Search name...");
        nameFilter.setStyle(uiUtils.textFieldStyle);

        TextField emailFilter = new TextField();
        emailFilter.setPromptText("🔍 Search email...");
        emailFilter.setStyle(uiUtils.textFieldStyle);

        Button applyFilterBtn = new Button("Apply Filters");
        applyFilterBtn.setStyle(uiUtils.primaryButtonStyle);
        applyFilterBtn.setOnMouseEntered(_ -> applyFilterBtn.setStyle("""
                -fx-background-color: linear-gradient(to right, #29c8ea, #0096c7);
                -fx-text-fill: white;
                -fx-background-radius: 12;
                -fx-padding: 8 22;
                -fx-font-size: 14px;
                -fx-font-weight: bold;
            """));

        applyFilterBtn.setOnMouseExited(_ -> applyFilterBtn.setStyle("""
                -fx-background-color: linear-gradient(to right, #00b4db, #0083b0);
                -fx-text-fill: white;
                -fx-background-radius: 12;
                -fx-padding: 8 22;
                -fx-font-size: 14px;
                -fx-font-weight: bold;
            """));
        HBox filterBar = new HBox(15, new Label("Filters:"), statusFilter, nameFilter, emailFilter, applyFilterBtn);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        filterBar.setPadding(new Insets(10, 0, 20, 0));

        contentArea.getChildren().addAll(title, filterBar);

        Runnable refresh = () -> {

            contentArea.getChildren().removeIf(node -> node instanceof FlowPane || node instanceof Label && node != title && node != filterBar);

            String statusQ = statusFilter.getValue();
            String nameQ = nameFilter.getText().trim().toLowerCase();
            String emailQ = emailFilter.getText().trim().toLowerCase();

            Label associatesTitle = new Label("👥 Associates");
            associatesTitle.setFont(new Font("Segoe UI Semibold", 18));
            associatesTitle.setTextFill(Color.web("#0083b0"));
            associatesTitle.setPadding(new Insets(20, 0, 10, 0));
            contentArea.getChildren().add(associatesTitle);

            FlowPane flowPaneAssociate = new FlowPane();
            flowPaneAssociate.setHgap(20);
            flowPaneAssociate.setVgap(20);
            flowPaneAssociate.setPadding(new Insets(0, 0, 20, 0));
            flowPaneAssociate.setAlignment(Pos.TOP_CENTER);

            Database.associates.stream()
                    .filter(m -> statusQ.equals("All Status") || m.getStatus().name().equalsIgnoreCase(statusQ))
                    .filter(m -> nameQ.isEmpty() || m.getCompleteName().toLowerCase().contains(nameQ))
                    .filter(m -> emailQ.isEmpty() || m.getEmailAddress().toLowerCase().contains(emailQ))
                    .forEach(m -> flowPaneAssociate.getChildren().add(
                            createMemberCard(m, false, uiUtils, contentArea, scrollPane, homeView, membersView,
                                    activitiesView, profileView, associate, isAdmin)
                    ));

            VBox addAssociateCard = createAddMemberCard(false, uiUtils, contentArea, scrollPane, homeView, membersView,
                    activitiesView, profileView, associate, isAdmin);
            flowPaneAssociate.getChildren().add(addAssociateCard);

            flowPaneAssociate.prefWrapLengthProperty().bind(scrollPane.widthProperty().subtract(40));
            contentArea.getChildren().add(flowPaneAssociate);


            Label adminsTitle = new Label("🛡 Administrators");
            adminsTitle.setFont(new Font("Segoe UI Semibold", 18));
            adminsTitle.setTextFill(Color.web("#0083b0"));
            adminsTitle.setPadding(new Insets(20, 0, 10, 0));
            contentArea.getChildren().add(adminsTitle);

            FlowPane flowPaneAdmin = new FlowPane();
            flowPaneAdmin.setHgap(20);
            flowPaneAdmin.setVgap(20);
            flowPaneAdmin.setPadding(new Insets(0, 0, 20, 0));
            flowPaneAdmin.setAlignment(Pos.TOP_CENTER);

            Database.administrators.stream()
                    .filter(m -> statusQ.equals("All Status") || m.getStatus().name().equalsIgnoreCase(statusQ))
                    .filter(m -> nameQ.isEmpty() || m.getCompleteName().toLowerCase().contains(nameQ))
                    .filter(m -> emailQ.isEmpty() || m.getEmailAddress().toLowerCase().contains(emailQ))
                    .forEach(admin -> flowPaneAdmin.getChildren().add(
                            createMemberCard(admin, true, uiUtils, contentArea, scrollPane, homeView, membersView,
                                    activitiesView, profileView, associate, isAdmin)
                    ));

            VBox addAdminCard = createAddMemberCard(true, uiUtils, contentArea, scrollPane, homeView, membersView,
                    activitiesView, profileView, associate, isAdmin);
            flowPaneAdmin.getChildren().add(addAdminCard);

            flowPaneAdmin.prefWrapLengthProperty().bind(scrollPane.widthProperty().subtract(40));
            contentArea.getChildren().add(flowPaneAdmin);

            scrollPane.setContent(contentArea);
        };

        applyFilterBtn.setOnAction(_ -> refresh.run());

        refresh.run();
    }


    /**
     * Helper method to create a visual "Add New" card.
     *
     * <p>When clicked, this card opens the creation form for either an Associate or an Administrator.</p>
     *
     * @param isAdminMember Indicates if the card is for adding an Administrator (true) or an Associate (false).
     * @param uiUtils       UI utility class.
     * @return A styled {@link VBox} representing the "Add" button.
     */
    private VBox createAddMemberCard(boolean isAdminMember, UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane,
                                     HomeView homeView, MembersView membersView, ActivitiesView activitiesView, ProfileView profileView,
                                     Associate associate, Boolean isAdmin) {
        VBox card = new VBox(15);
        card.setPadding(new Insets(25));
        card.setPrefWidth(320);
        card.setMaxWidth(320);
        card.setAlignment(Pos.CENTER);
        card.setStyle("""
                -fx-background-color: #e8f5e9;
                -fx-background-radius: 14;
                -fx-border-color: #a5d6a7;
                -fx-border-width: 2;
                -fx-border-radius: 14;
                -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 10, 0.15, 0, 2);
            """);

        card.setOnMouseEntered(_ -> card.setStyle("""
                -fx-background-color: #c8e6c9;
                -fx-background-radius: 14;
                -fx-border-color: #81c784;
                -fx-border-width: 2;
                -fx-border-radius: 14;
                -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.25), 12, 0.20, 0, 3);
            """));

        card.setOnMouseExited(_ -> card.setStyle("""
                -fx-background-color: #e8f5e9;
                -fx-background-radius: 14;
                -fx-border-color: #a5d6a7;
                -fx-border-width: 2;
                -fx-border-radius: 14;
                -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 10, 0.15, 0, 2);
            """));

        Label icon = new Label(isAdminMember ? "➕🛡" : "➕👤");
        icon.setFont(new Font(32));

        String memberType = isAdminMember ? "Administrator" : "Associate";
        Label titleLabel = new Label("Add New " + memberType);
        titleLabel.setFont(new Font("Segoe UI Semibold", 16));
        titleLabel.setTextFill(Color.web("#2e7d32"));
        titleLabel.setAlignment(Pos.CENTER);

        Label descLabel = new Label("Click to create a new " + memberType.toLowerCase());
        descLabel.setFont(new Font("Segoe UI", 12));
        descLabel.setTextFill(Color.web("#555"));
        descLabel.setAlignment(Pos.CENTER);
        descLabel.setWrapText(true);

        VBox contentBox = new VBox(8, icon, titleLabel, descLabel);
        contentBox.setAlignment(Pos.CENTER);

        card.getChildren().add(contentBox);

        card.setOnMouseClicked(_ -> showAddMemberFormWithRole(isAdminMember, uiUtils, contentArea, scrollPane, homeView,
                membersView, activitiesView, profileView, associate, isAdmin));

        return card;
    }

    /**
     * Opens a modal form to register a new member with the specified role.
     *
     * <p>Handles input validation (empty fields, email regex, age range, duplicate email)
     * and persists the new member to the database.</p>
     *
     * @param isAdminMember True to create an Administrator, False for an Associate.
     * @param uiUtils       UI utility class for alerts and styling.
     */
    private void showAddMemberFormWithRole(boolean isAdminMember, UiUtils uiUtils, VBox contentArea,
                                           ScrollPane scrollPane, HomeView homeView, MembersView membersView, ActivitiesView activitiesView,
                                           ProfileView profileView, Associate associate, Boolean isAdmin) {
        Stage form = new Stage();
        form.setTitle("Add New " + (isAdminMember ? "Administrator" : "Associate"));

        VBox layout = new VBox(15);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("""
                -fx-background-color: #f9f9f9;
            """);

        Label title = new Label("Add New " + (isAdminMember ? "Administrator" : "Associate"));
        title.setFont(new Font("Segoe UI Semibold", 18));
        title.setTextFill(Color.web("#0083b0"));

        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        uiUtils.styleField(nameField);

        TextField surnameField = new TextField();
        surnameField.setPromptText("Surname");
        uiUtils.styleField(surnameField);

        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        uiUtils.styleField(emailField);

        PasswordField passField = new PasswordField();
        passField.setPromptText("Password (min. 8 characters)");
        uiUtils.styleField(passField);

        TextField ageField = new TextField();
        ageField.setPromptText("Age");
        uiUtils.styleField(ageField);

        Label errorLabel = new Label();
        errorLabel.setTextFill(Color.RED);

        Button createBtn = new Button("Create " + (isAdminMember ? "Administrator" : "Associate"));
        createBtn.setStyle("""
                -fx-background-color: #43a047;
                -fx-text-fill: white;
                -fx-background-radius: 10;
                -fx-font-weight: bold;
                -fx-padding: 8 16;
            """);

        createBtn.setOnAction(_ -> {
            String name = nameField.getText().trim();
            String surname = surnameField.getText().trim();
            String email = emailField.getText().trim();
            String password = passField.getText().trim();
            String ageStr = ageField.getText().trim();

            if (name.isEmpty() || surname.isEmpty() || email.isEmpty() || password.isEmpty() || ageStr.isEmpty()) {
                errorLabel.setText("⚠ Please fill all fields");
                return;
            }

            if (!uiUtils.isValidEmail(email)) {
                errorLabel.setText("⚠ Please enter a valid email");
                return;
            }

            String passwordError = uiUtils.isValidPassword(password);
            if (passwordError != null) {
                errorLabel.setText("⚠ " + passwordError);
                return;
            }

            if (uiUtils.isEmailAlreadyRegistered(email)) {
                errorLabel.setText("⚠ This email is already registered");
                return;
            }

            int age;
            try {
                age = Integer.parseInt(ageStr);
                if (age < 0) {
                    errorLabel.setText("⚠ Age must be a positive number");
                    return;
                }
            } catch (NumberFormatException e) {
                errorLabel.setText("⚠ Age must be a valid number");
                return;
            }

            if (isAdminMember) {
                Administrator admin = new Administrator();
                admin.setFirstName(name);
                admin.setSurname(surname);
                admin.setEmailAddress(email);
                admin.setAge(age);
                admin.setPasswordAlreadyHashed(password);

                Database.administrators.add(admin);
                Database.saveAdministrators();
            } else {
                Associate a = new Associate(surname, name, email, password, age);

                Database.associates.add(a);
                Database.saveAssociates();
            }

            form.close();
            this.showManageMembers(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView,
                    associate, isAdmin);
        });

        layout.getChildren().addAll(title, nameField, surnameField, emailField, passField, ageField, errorLabel,
                createBtn);

        Scene scene = new Scene(layout, 350, 450);
        form.setScene(scene);
        form.setResizable(false);
        form.show();
    }

    /**
     * Creates a card for an existing member with management controls.
     *
     * <p>Includes buttons for:</p>
     * <ul>
     * <li>Changing status (Active/Suspended/etc.)</li>
     * <li>Editing details</li>
     * <li>Locking/Unlocking the account</li>
     * <li>Promoting/Demoting (Role swap between Admin and Associate)</li>
     * <li>Removing the member</li>
     * </ul>
     *
     * @param member        The {@link Associate} or {@link Administrator} object.
     * @param isAdminMember True if the member is an Admin.
     * @return A VBox card component.
     */
    private VBox createMemberCard(Object member, boolean isAdminMember, UiUtils uiUtils, VBox contentArea,
                                  ScrollPane scrollPane, HomeView homeView, MembersView membersView, ActivitiesView activitiesView,
                                  ProfileView profileView, Associate associate, Boolean isAdmin) {
        VBox card = new VBox(12);
        card.setPadding(new Insets(20));
        card.setPrefWidth(320);
        card.setMaxWidth(320);
        card.setStyle("""
                -fx-background-color: #ffffff;
                -fx-background-radius: 14;
                -fx-border-color: #b3e5fc;
                -fx-border-width: 1;
                -fx-border-radius: 14;
                -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 10, 0.15, 0, 2);
            """);

        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);

        Label icon = new Label(isAdminMember ? "🛡" : "👤");
        icon.setFont(new Font(20));

        String memberName = isAdminMember ? ((Administrator) member).getCompleteName()
                : ((Associate) member).getCompleteName();
        String memberEmail = isAdminMember ? ((Administrator) member).getEmailAddress()
                : ((Associate) member).getEmailAddress();
        MemberStatus memberStatus = isAdminMember ? ((Administrator) member).getStatus()
                : ((Associate) member).getStatus();
        boolean isLocked = isAdminMember ? ((Administrator) member).isLocked() : ((Associate) member).isLocked();

        VBox nameBox = new VBox(2);
        Label nameLabel = new Label(memberName);
        nameLabel.setFont(new Font("Segoe UI Semibold", 16));
        nameLabel.setTextFill(Color.web("#01579b"));

        Label emailLabel = new Label(memberEmail);
        emailLabel.setFont(new Font("Segoe UI", 12));
        emailLabel.setTextFill(Color.web("#666"));

        nameBox.getChildren().addAll(nameLabel, emailLabel);
        header.getChildren().addAll(icon, nameBox);

        ComboBox<MemberStatus> statusBox = new ComboBox<>();
        statusBox.getItems().addAll(MemberStatus.values());
        statusBox.setValue(memberStatus);
        statusBox.setMaxWidth(Double.MAX_VALUE);
        statusBox.setPrefWidth(Double.MAX_VALUE);
        uiUtils.applyStatusColor(statusBox, memberStatus);

        statusBox.setOnAction(_ -> {
            MemberStatus newStatus = statusBox.getValue();
            if (isAdminMember) {
                ((Administrator) member).setStatus(newStatus.toString());
                Database.saveAdministrators();
            } else {
                ((Associate) member).setStatus(newStatus.toString());
                Database.saveAssociates();
            }
            uiUtils.applyStatusColor(statusBox, newStatus);
        });

        HBox buttonRow1 = new HBox(8);
        buttonRow1.setAlignment(Pos.CENTER);

        Button editBtn = new Button("✏ Edit");
        editBtn.setStyle(
                "-fx-background-color: #1976d2; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;");

        Button lockBtn = new Button(isLocked ? "🔓 Unlock" : "🔒 Lock");
        lockBtn.setStyle(isLocked
                ? "-fx-background-color: #388e3c; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;"
                : "-fx-background-color: #f57c00; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;");

        HBox buttonRow2 = new HBox(8);
        buttonRow2.setAlignment(Pos.CENTER);

        Button roleBtn = new Button(isAdminMember ? "⬇ Demote" : "⬆ Promote");
        roleBtn.setStyle(isAdminMember
                ? "-fx-background-color: #ffa000; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;"
                : "-fx-background-color: #00b4db; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;");

        Button deleteBtn = new Button("🗑 Remove");
        deleteBtn.setStyle(
                "-fx-background-color: #e53935; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;");

        editBtn.setOnAction(_ -> this.showEditMemberDialog(member, uiUtils, contentArea, scrollPane, homeView,
                membersView, activitiesView, profileView, associate, isAdmin));

        lockBtn.setOnAction(_ -> {
            if (isAdminMember) {
                Administrator admin = (Administrator) member;
                if (admin.isLocked())
                    admin.removeLock();
                else
                    admin.addLock();
                Database.saveAdministrators();
            } else {
                Associate assoc = (Associate) member;
                if (assoc.isLocked())
                    assoc.removeLock();
                else
                    assoc.addLock();
                Database.saveAssociates();
            }
            this.showManageMembers(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView,
                    associate, isAdmin);
        });

        roleBtn.setOnAction(_ -> {
            if (isAdminMember) {
                // Demote to Associate
                Administrator admin = (Administrator) member;
                Associate newAssoc = new Associate(admin.getAssociateId(), admin.getSurname(), admin.getFirstName(),
                        admin.getEmailAddress(), "", admin.getAge(), admin.getStatus().toString(),
                        admin.getDateOfSubscription());
                newAssoc.setPasswordAlreadyHashed(admin.getHashedPassword());

                Database.administrators.remove(admin);
                Database.associates.add(newAssoc);
                Database.saveAdministrators();
                Database.saveAssociates();
            } else {
                // Promote to Admin
                Associate assoc = (Associate) member;
                Administrator newAdmin = new Administrator();
                newAdmin.setAssociateId(assoc.getAssociateId());
                newAdmin.setFirstName(assoc.getFirstName());
                newAdmin.setSurname(assoc.getSurname());
                newAdmin.setEmailAddress(assoc.getEmailAddress());
                newAdmin.setPasswordAlreadyHashed(assoc.getHashedPassword());
                newAdmin.setAge(assoc.getAge());
                newAdmin.setStatus(assoc.getStatus().toString());
                newAdmin.setDateOfSubscription(assoc.getDateOfSubscription());

                Database.associates.remove(assoc);
                Database.administrators.add(newAdmin);
                Database.saveAssociates();
                Database.saveAdministrators();
            }
            this.showManageMembers(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView,
                    associate, isAdmin);
        });

        deleteBtn.setOnAction(_ -> {
            if (isAdminMember) {
                Database.administrators.remove(member);
                Database.saveAdministrators();
            } else {
                Database.associates.remove(member);
                Database.saveAssociates();
            }
            this.showManageMembers(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView,
                    associate, isAdmin);
        });

        buttonRow1.getChildren().addAll(editBtn, lockBtn);
        buttonRow2.getChildren().addAll(roleBtn, deleteBtn);

        card.getChildren().addAll(header, statusBox, buttonRow1, buttonRow2);
        return card;
    }

    /**
     * Shows a dialog to edit the profile data of an existing member.
     *
     * <p>Populates the fields with current data, validates changes, and handles
     * rapid actions (Lock, Promote, Remove) directly from the dialog.</p>
     *
     * @param member The member object (Associate or Administrator).
     */
    public void showEditMemberDialog(Object member, UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane,
                                     HomeView homeView, MembersView membersView, ActivitiesView activitiesView, ProfileView profileView,
                                     Associate associate, Boolean isAdmin) {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Edit Member Data");

        boolean isMemberAdmin = member instanceof Administrator;

        dialog.setHeaderText(null);

        VBox mainContainer = new VBox(15);
        mainContainer.setPadding(new Insets(20));
        mainContainer.setStyle("""
                -fx-background-color: #f9f9f9;
            """);

        Label title = new Label(isMemberAdmin ? "✏️ Edit Administrator" : "✏️ Edit Associate");
        title.setFont(new Font("Segoe UI Semibold", 18));
        title.setTextFill(Color.web("#0083b0"));
        title.setAlignment(Pos.CENTER);
        title.setMaxWidth(Double.MAX_VALUE);

        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(12);
        grid.setPadding(new Insets(10, 0, 10, 0));

        TextField nameField = new TextField(
                isMemberAdmin ? ((Administrator) member).getFirstName() : ((Associate) member).getFirstName());
        TextField surnameField = new TextField(
                isMemberAdmin ? ((Administrator) member).getSurname() : ((Associate) member).getSurname());
        TextField emailField = new TextField(
                isMemberAdmin ? ((Administrator) member).getEmailAddress() : ((Associate) member).getEmailAddress());
        TextField ageField = new TextField(
                String.valueOf(isMemberAdmin ? ((Administrator) member).getAge() : ((Associate) member).getAge()));

        uiUtils.styleField(nameField);
        uiUtils.styleField(surnameField);
        uiUtils.styleField(emailField);
        uiUtils.styleField(ageField);

        Font labelFont = new Font("Segoe UI Semibold", 12);
        for (Label lbl : new Label[]{new Label("Name:"), new Label("Surname:"), new Label("Email:"),
                new Label("Age:")}) {
            lbl.setFont(labelFont);
            lbl.setTextFill(Color.web("#333"));
        }

        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Surname:"), 0, 1);
        grid.add(surnameField, 1, 1);
        grid.add(new Label("Email:"), 0, 2);
        grid.add(emailField, 1, 2);
        grid.add(new Label("Age:"), 0, 3);
        grid.add(ageField, 1, 3);

        Label errorLabel = new Label();
        errorLabel.setTextFill(Color.RED);
        errorLabel.setWrapText(true);
        grid.add(errorLabel, 0, 4, 2, 1);

        Label actionsTitle = new Label("Quick Actions");
        actionsTitle.setFont(new Font("Segoe UI Semibold", 14));
        actionsTitle.setTextFill(Color.web("#0083b0"));
        actionsTitle.setPadding(new Insets(10, 0, 5, 0));
        grid.add(actionsTitle, 0, 5, 2, 1);

        HBox actionsBox = new HBox(10);
        actionsBox.setAlignment(Pos.CENTER);

        boolean isLocked = isMemberAdmin ? ((Administrator) member).isLocked() : ((Associate) member).isLocked();

        Button lockBtn = new Button(isLocked ? "🔓 Unlock" : "🔒 Lock");
        lockBtn.setStyle(isLocked
                ? "-fx-background-color: #388e3c; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;"
                : "-fx-background-color: #f57c00; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;");

        Button roleBtn = new Button(isMemberAdmin ? "⬇ Demote to Associate" : "⬆ Promote to Admin");
        roleBtn.setStyle(isMemberAdmin
                ? "-fx-background-color: #ffa000; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;"
                : "-fx-background-color: #00b4db; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;");

        Button removeBtn = new Button("🗑 Remove");
        removeBtn.setStyle(
                "-fx-background-color: #e53935; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;");

        actionsBox.getChildren().addAll(lockBtn, roleBtn, removeBtn);
        grid.add(actionsBox, 0, 6, 2, 1);

        mainContainer.getChildren().addAll(title, grid);
        dialog.getDialogPane().setContent(mainContainer);

        ButtonType saveButtonType = new ButtonType("Save Changes", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButtonType = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, cancelButtonType);

        Button saveButton = (Button) dialog.getDialogPane().lookupButton(saveButtonType);
        Button cancelButton = (Button) dialog.getDialogPane().lookupButton(cancelButtonType);

        saveButton.setStyle("""
                -fx-background-color: #00b4db;
                -fx-text-fill: white;
                -fx-background-radius: 8;
                -fx-font-weight: bold;
                -fx-padding: 8 16;
            """);

        cancelButton.setStyle("""
                -fx-background-color: #ef5350;
                -fx-text-fill: white;
                -fx-background-radius: 8;
                -fx-font-weight: bold;
                -fx-padding: 8 16;
            """);

        lockBtn.setOnAction(_ -> {
            if (isMemberAdmin) {
                Administrator admin = (Administrator) member;
                if (admin.isLocked())
                    admin.removeLock();
                else
                    admin.addLock();
                Database.saveAdministrators();
            } else {
                Associate assoc = (Associate) member;
                if (assoc.isLocked())
                    assoc.removeLock();
                else
                    assoc.addLock();
                Database.saveAssociates();
            }
            dialog.close();
            this.showManageMembers(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView,
                    associate, isAdmin);
        });

        roleBtn.setOnAction(_ -> {
            if (isMemberAdmin) {
                // Demote to Associate
                Administrator admin = (Administrator) member;
                Associate newAssoc = new Associate(admin.getAssociateId(), admin.getSurname(), admin.getFirstName(),
                        admin.getEmailAddress(), "", admin.getAge(), admin.getStatus().toString(),
                        admin.getDateOfSubscription());
                newAssoc.setPasswordAlreadyHashed(admin.getHashedPassword());

                Database.administrators.remove(admin);
                Database.associates.add(newAssoc);
                Database.saveAdministrators();
                Database.saveAssociates();
            } else {
                // Promote to Admin
                Associate assoc = (Associate) member;
                Administrator newAdmin = new Administrator();
                newAdmin.setAssociateId(assoc.getAssociateId());
                newAdmin.setFirstName(assoc.getFirstName());
                newAdmin.setSurname(assoc.getSurname());
                newAdmin.setEmailAddress(assoc.getEmailAddress());
                newAdmin.setPasswordAlreadyHashed(assoc.getHashedPassword());
                newAdmin.setAge(assoc.getAge());
                newAdmin.setStatus(assoc.getStatus().toString());
                newAdmin.setDateOfSubscription(assoc.getDateOfSubscription());

                Database.associates.remove(assoc);
                Database.administrators.add(newAdmin);
                Database.saveAssociates();
                Database.saveAdministrators();
            }
            dialog.close();
            this.showManageMembers(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView,
                    associate, isAdmin);
        });

        removeBtn.setOnAction(_ -> {
            if (isMemberAdmin) {
                Database.administrators.remove(member);
                Database.saveAdministrators();
            } else {
                Database.associates.remove(member);
                Database.saveAssociates();
            }
            dialog.close();
            this.showManageMembers(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView,
                    associate, isAdmin);
        });

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                String name = nameField.getText().trim();
                String surname = surnameField.getText().trim();
                String email = emailField.getText().trim();
                String ageText = ageField.getText().trim();

                if (name.isEmpty() || surname.isEmpty() || email.isEmpty() || ageText.isEmpty()) {
                    errorLabel.setText("⚠ All fields are required");
                    return null;
                }

                if (!uiUtils.isValidEmail(email)) {
                    errorLabel.setText("⚠ Please enter a valid email address");
                    return null;
                }

                int age;
                try {
                    age = Integer.parseInt(ageText);
                    if (age < 0 || age > 150) {
                        errorLabel.setText("⚠ Age must be between 0 and 150");
                        return null;
                    }
                } catch (NumberFormatException e) {
                    errorLabel.setText("⚠ Age must be a valid number");
                    return null;
                }

                String currentEmail = isMemberAdmin ? ((Administrator) member).getEmailAddress()
                        : ((Associate) member).getEmailAddress();
                if (!email.equalsIgnoreCase(currentEmail) && uiUtils.isEmailAlreadyRegistered(email)) {
                    errorLabel.setText("⚠ This email is already registered by another user");
                    return null;
                }

                if (isMemberAdmin) {
                    Administrator admin = (Administrator) member;
                    admin.setFirstName(name);
                    admin.setSurname(surname);
                    admin.setEmailAddress(email);
                    admin.setAge(age);
                    Database.saveAdministrators();
                } else {
                    Associate assoc = (Associate) member;
                    assoc.setFirstName(name);
                    assoc.setSurname(surname);
                    assoc.setEmailAddress(email);
                    assoc.setAge(age);
                    Database.saveAssociates();
                }
                this.showManageMembers(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView,
                        profileView, associate, isAdmin);
            }
            return null;
        });

        dialog.getDialogPane().setMinWidth(450);
        dialog.getDialogPane().setMinHeight(400);

        dialog.showAndWait();
    }
}