package application;

import SportCircle.Activity;
import SportCircle.Associate;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Utility class responsible for generating personalized activity recommendations
 * for {@link Associate} users within the SportCircle application.
 *
 * 
 *
 * <p>The recommendation engine operates based on a frequency analysis of the user's
 * historical participation. It performs the following steps:</p>
 * <ol>
 * <li><b>Data Loading:</b> Parses the {@code activitiesHistory.csv} file to retrieve the user's past events.</li>
 * <li><b>Pattern Recognition:</b> Identifies the user's most frequently played sport and preferred time of day (Morning, Afternoon, Evening).</li>
 * <li><b>Filtering:</b> Scans the database of upcoming activities and filters them based on these identified preferences.</li>
 * </ol>
 *
 * <p>This class is stateless (except for the file path constant) and uses static methods
 * to provide recommendations.</p>
 *
 * @see Activity
 * @see Associate
 * @see Database
 */
public class ActivityRecommender {

    /**
     * The file system path to the CSV file containing historical activity data.
     * <p>Expected format: {@code name;sport;type;date;time;participants}</p>
     */
    private static final String HISTORY_PATH = "data/activitiesHistory.csv";

    /**
     * Generates a curated list of recommended activities for a specific user based on
     * their historical preferences for both sport type and time of day.
     *
     * <p>This method combines the logic of {@link #findFavoredSport(List)} and
     * {@link #findFavoredHourRange(List)} to apply a strict filter on the available
     * database activities.</p>
     *
     * @param user The {@link Associate} for whom to generate recommendations.
     * @return A list of up to 5 recommended {@link Activity} objects, or an empty list
     * if the user has no history or no matches are found.
     */
    public static List<Activity> recommendActivities(Associate user) {

        List<Activity> pastActivities = loadUserPastActivities(user);

        if (pastActivities.isEmpty()) {
            return Collections.emptyList();
        }

        String favoredSport = findFavoredSport(pastActivities);
        String favoredHourRange = findFavoredHourRange(pastActivities);

        return Database.activities.stream()
                .filter(a -> favoredSport == null || a.getSportType().toString().equalsIgnoreCase(favoredSport))
                .filter(a -> {
                    try {
                        return favoredHourRange == null ||
                                matchesHourRange(a.getActivityTime().split(":")[0], favoredHourRange);
                    } catch (Exception e) {
                        return false;
                    }
                })
                .limit(5)
                .collect(Collectors.toList());
    }

    /**
     * Parses the history CSV file to load all activities the specified user has participated in.
     *
     * <p>The method reads the file line by line, parses the semicolon-separated values,
     * and checks if the {@code user}'s ID is present in the participants column.</p>
     *
     * @param user The {@link Associate} whose history is being queried.
     * @return A list of {@link Activity} objects representing the user's past participation.
     * Returns an empty list if the file cannot be read or no records are found.
     */
    private static List<Activity> loadUserPastActivities(Associate user) {
        List<Activity> past = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(HISTORY_PATH))) {

            String line;

            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] data = line.split(";");
                // Expecting at least 6 columns: name, sport, type, date, time, participants
                if (data.length < 6) continue;

                String activityName = data[0];
                String sport = data[1];
                String type = data[2];
                String date = data[3];
                String time = data[4];
                String participants = data[5];

                // Check if user ID is in the participants string (simple containment check)
                if (!participants.contains(user.getAssociateId())) {
                    continue;
                }

                Activity activity = new Activity(
                        activityName,
                        sport,
                        type,
                        date,
                        time
                );

                // Temporarily subscribe the user to this reconstructed activity object
                // to accurately reflect state, though this object is local to this method.
                activity.subscribeAssociate(user);
                past.add(activity);
            }

        } catch (Exception e) {
            System.err.println("Error reading activitiesHistory.csv: " + e.getMessage());
        }

        return past;
    }

    /**
     * Analyzes the user's past activities to determine their favorite sport.
     *
     * <p>This method groups activities by sport type and counts the occurrences,
     * returning the sport with the highest frequency.</p>
     *
     * @param activities The list of past activities to analyze.
     * @return The name of the most frequent sport (e.g., "TENNIS"), or {@code null} if the list is empty.
     */
    private static String findFavoredSport(List<Activity> activities) {
        return activities.stream()
                .collect(Collectors.groupingBy(a -> a.getSportType().name(), Collectors.counting()))
                .entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    /**
     * Analyzes the user's past activities to determine their preferred time range.
     *
     * <p>Time ranges are categorized as:
     * <ul>
     * <li><b>MORNING:</b> Before 12:00</li>
     * <li><b>AFTERNOON:</b> 12:00 to 17:59</li>
     * <li><b>EVENING:</b> 18:00 onwards</li>
     * </ul>
     *
     * @param activities The list of past activities to analyze.
     * @return The identifier of the most frequent time range (e.g., "EVENING"), or {@code null} if undetermined.
     */
    private static String findFavoredHourRange(List<Activity> activities) {
        return activities.stream()
                .collect(Collectors.groupingBy(a -> getHourRange(a.getActivityTime()), Collectors.counting()))
                .entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    /**
     * Helper method to convert a specific time string into a general time range category.
     *
     * @param hour A string representing the time (format "HH:mm").
     * @return "MORNING", "AFTERNOON", "EVENING", or {@code null} if the format is invalid.
     */
    private static String getHourRange(String hour) {
        try {
            int h = Integer.parseInt(hour.split(":")[0]);
            if (h < 12) return "MORNING";
            if (h < 18) return "AFTERNOON";
            return "EVENING";
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Helper method to check if a specific hour falls within a favored time range.
     *
     * @param time  The hour string (e.g., "14").
     * @param range The target range ("MORNING", "AFTERNOON", "EVENING").
     * @return {@code true} if the time matches the range, {@code false} otherwise.
     */
    private static boolean matchesHourRange(String time, String range) {
        try {
            int h = Integer.parseInt(time);
            return switch (range) {
                case "MORNING" -> h < 12;
                case "AFTERNOON" -> h >= 12 && h < 18;
                case "EVENING" -> h >= 18;
                default -> false;
            };
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Extracts the hour component from a time string.
     *
     * @param time The time string (format "HH:mm").
     * @return The hour part as a String, or "0" if parsing fails.
     */
    public static String extractHour(String time) {
        try {
            return time.split(":")[0];
        } catch (Exception e) {
            return "0";
        }
    }

    /**
     * Generates a list of recommended activities based <b>only</b> on the user's favorite sport,
     * ignoring time preferences.
     *
     * @param user The {@link Associate} for whom to generate recommendations.
     * @return A list of up to 5 activities matching the user's favorite sport.
     */
    public static List<Activity> recommendBySport(Associate user) {
        List<Activity> past = loadUserPastActivities(user);
        String sport = findFavoredSport(past);
        if (sport == null) return List.of();

        return Database.activities.stream()
                .filter(a -> a.getSportType().name().equalsIgnoreCase(sport))
                .limit(5)
                .collect(Collectors.toList());
    }

    /**
     * Generates a list of recommended activities based <b>only</b> on the user's preferred time of day,
     * ignoring sport preferences.
     *
     * @param user The {@link Associate} for whom to generate recommendations.
     * @return A list of up to 5 activities matching the user's preferred time range.
     */
    public static List<Activity> recommendByHour(Associate user) {
        List<Activity> past = loadUserPastActivities(user);
        String range = findFavoredHourRange(past);
        if (range == null) return List.of();

        return Database.activities.stream()
                .filter(a -> matchesHourRange(a.getActivityTime().split(":")[0], range))
                .limit(5)
                .collect(Collectors.toList());
    }

    /**
     * Generates a list of recommended activities that match <b>both</b> the user's favorite sport
     * and their preferred time range.
     *
     * <p>This is functionally similar to {@link #recommendActivities(Associate)} but explicitly
     * separated for modularity.</p>
     *
     * @param user The {@link Associate} for whom to generate recommendations.
     * @return A list of up to 5 activities matching both criteria.
     */
    public static List<Activity> recommendCombined(Associate user) {
        List<Activity> past = loadUserPastActivities(user);

        String sport = findFavoredSport(past);
        String range = findFavoredHourRange(past);

        if (sport == null && range == null) return List.of();

        return Database.activities.stream()
                .filter(a -> sport == null || a.getSportType().name().equalsIgnoreCase(sport))
                .filter(a -> range == null || matchesHourRange(a.getActivityTime().split(":")[0], range))
                .limit(5)
                .collect(Collectors.toList());
    }
}