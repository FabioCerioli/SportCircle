package application;

import SportCircle.Associate;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * Controls the layout and interaction logic for the application's Home screen.
 *
 * 
 *
 * <p>The {@code HomeView} serves as the central landing page after authentication.
 * It provides a high-level navigation hub using interactive cards that direct the user to:</p>
 * <ul>
 * <li><b>Activities:</b> To view or join sports events.</li>
 * <li><b>Members:</b> To browse the directory of associates.</li>
 * <li><b>Profile:</b> To manage personal settings.</li>
 * <li><b>AI Suggestions:</b> To view personalized recommendations.</li>
 * </ul>
 *
 * <p><b>Role-Based Display:</b> If the logged-in user is identified as an administrator,
 * this view dynamically renders an additional "Admin Tools" section containing cards for
 * managing members and activities.</p>
 *
 * @see UiUtils
 */
public class HomeView {

    /**
     * Renders the complete Home interface into the primary content area.
     *
     * <p>This method constructs the UI hierarchy programmatically using JavaFX containers.
     * It clears the existing content in {@code contentArea} and repopulates it with
     * the dashboard grid. Each card is assigned a mouse click listener that triggers
     * the transition to the specific view controller (e.g., {@code activitiesView.showActivities(...)}).</p>
     *
     * @param uiUtils        Utility class used for consistent styling and factory methods (e.g., creating cards).
     * @param contentArea    The VBox container where the UI elements will be added.
     * @param scrollPane     The parent ScrollPane ensuring the content is scrollable.
     * @param homeView       Reference to the HomeView (self) for navigation contexts.
     * @param membersView    Reference to the MembersView controller.
     * @param activitiesView Reference to the ActivitiesView controller.
     * @param profileView    Reference to the ProfileView controller.
     * @param associate      The currently authenticated user session.
     * @param isAdmin        Flag indicating if the user has administrative privileges.
     */
    public void showHome(UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane, HomeView homeView,
                         MembersView membersView, ActivitiesView activitiesView, ProfileView profileView,
                         Associate associate, Boolean isAdmin) {

        VBox homeRoot = new VBox(20);
        homeRoot.setPadding(new Insets(30));
        homeRoot.setAlignment(Pos.TOP_CENTER);

        Label title = new Label("🏋️‍♂️ Welcome to Sport Circle");
        title.setFont(Font.font("Segoe UI Semibold", 28));
        title.setTextFill(Color.web("#01579b"));

        HBox mainCards = new HBox(20);
        mainCards.setAlignment(Pos.CENTER);

        VBox cardActivities = uiUtils.createHomeCard("🏆", "Activities", "View and join sport activities");
        cardActivities.setOnMouseClicked(_ -> activitiesView.showActivities(
                uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView, associate, isAdmin
        ));

        VBox cardMembers = uiUtils.createHomeCard("👥", "Members", "Explore the list of sport members");
        cardMembers.setOnMouseClicked(_ -> membersView.showMembers(
                uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView, associate, isAdmin
        ));

        VBox cardProfile = uiUtils.createHomeCard("👤", "Your Profile", "Manage your personal information");
        cardProfile.setOnMouseClicked(_ -> profileView.showProfile(
                uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView, associate, isAdmin
        ));

        mainCards.getChildren().addAll(cardActivities, cardMembers, cardProfile);

        VBox adminBox = new VBox(15);
        adminBox.setAlignment(Pos.CENTER);

        if (isAdmin) {
            Label adminTitle = new Label("🔧 Admin Tools");
            adminTitle.setFont(Font.font("Segoe UI Semibold", 20));
            adminTitle.setTextFill(Color.web("#0277bd"));

            HBox adminCards = new HBox(20);
            adminCards.setAlignment(Pos.CENTER);

            VBox cardManageMembers = uiUtils.createHomeCard("👑", "Manage Members",
                    "Edit, remove, upgrade members");
            cardManageMembers.setOnMouseClicked(_ -> membersView.showManageMembers(
                    uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView, associate, isAdmin
            ));

            VBox cardManageActivities = uiUtils.createHomeCard("🛠", "Manage Activities",
                    "Create or delete activities");
            cardManageActivities.setOnMouseClicked(_ -> activitiesView.showManageActivities(
                    uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView, associate, isAdmin
            ));

            adminCards.getChildren().addAll(cardManageMembers, cardManageActivities);
            adminBox.getChildren().addAll(adminTitle, adminCards);
        }

        VBox logoutCard = uiUtils.createHomeCard("🚪", "Logout", "Exit your account safely");
        logoutCard.setOnMouseClicked(_ -> Main.showLogin());

        VBox logoutContainer = new VBox(logoutCard);
        logoutContainer.setAlignment(Pos.CENTER);
        logoutContainer.setPadding(new Insets(10, 0, 0, 0));

        VBox aiSuggestCard = uiUtils.createHomeCard("🤖", "AI Suggestions",
                "Personalized activity recommendations");

        aiSuggestCard.setOnMouseClicked(_ -> activitiesView.showAISuggestions(
                uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView, profileView, associate, isAdmin
        ));

        mainCards.getChildren().add(aiSuggestCard);

        homeRoot.getChildren().addAll(title, mainCards, adminBox, logoutContainer);
        contentArea.getChildren().setAll(homeRoot);
    }
}