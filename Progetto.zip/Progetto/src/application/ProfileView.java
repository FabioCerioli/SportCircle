package application;

import SportCircle.Associate;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * Manages the graphical user interface for the User Profile section of the Sport Circle application.
 *
 * 
 *
 * <p>This view controller is responsible for two main operational modes:</p>
 * <ul>
 * <li><b>Read Mode ({@code showProfile}):</b> Displays user details, membership status, and navigation shortcuts.</li>
 * <li><b>Edit Mode ({@code showEditProfile}):</b> Provides a form for updating personal information with validation logic.</li>
 * </ul>
 *
 * <p>The layout uses a responsive {@link FlowPane} to organize navigation cards, ensuring
 * adaptability to different window sizes.</p>
 *
 * @see UiUtils
 */
public class ProfileView {

    /**
     * Renders the main profile dashboard.
     *
     * <p>The dashboard consists of:</p>
     * <ul>
     * <li><b>Header Card:</b> Displays the user's avatar, name, email, age, and a colored status badge.</li>
     * <li><b>Navigation Grid:</b> A set of clickable cards allowing the user to:
     * <ul>
     * <li>Edit their profile.</li>
     * <li>View their activity history.</li>
     * <li>Check membership details.</li>
     * <li>Access <b>Admin Tools</b> (visible only if {@code isAdmin} is true).</li>
     * </ul>
     * </li>
     * </ul>
     *
     * @param uiUtils        Utility class for UI styling and factory methods.
     * @param contentArea    The main container where the profile UI is rendered.
     * @param scrollPane     The parent scroll container.
     * @param homeView       Reference to HomeView for navigation.
     * @param membersView    Reference to MembersView for navigation.
     * @param activitiesView Reference to ActivitiesView for navigation.
     * @param profileView    Reference to this ProfileView (self).
     * @param associate      The currently logged-in user whose data is displayed.
     * @param isAdmin        Flag indicating if the user has administrative privileges.
     */
    public void showProfile(
            UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane,
            HomeView homeView, MembersView membersView,
            ActivitiesView activitiesView, ProfileView profileView,
            Associate associate, Boolean isAdmin) {

        contentArea.getChildren().clear();

        Label title = new Label("👤 My Profile");
        title.setFont(new Font("Segoe UI Semibold", 26));
        title.setTextFill(Color.web("#0083b0"));
        contentArea.getChildren().add(title);

        VBox headerCard = new VBox(10);
        headerCard.setPadding(new Insets(25));
        headerCard.setStyle("""
                -fx-background-color: #ffffff;
                -fx-background-radius: 14;
                -fx-border-color: #90caf9;
                -fx-border-width: 1;
                -fx-border-radius: 14;
                -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.10), 10, 0.1, 0, 2);
            """);

        Label profileIcon = new Label("👤");
        profileIcon.setFont(new Font(36));

        Label fullName = new Label(associate.getFirstName() + " " + associate.getSurname());
        fullName.setFont(new Font("Segoe UI Semibold", 22));
        fullName.setTextFill(Color.web("#01579b"));

        Label email = new Label("📧 " + associate.getEmailAddress());
        email.setFont(new Font("Segoe UI", 14));
        email.setTextFill(Color.web("#444"));

        Label age = new Label("🎂 Age: " + associate.getAge());
        age.setFont(new Font("Segoe UI", 14));
        age.setTextFill(Color.web("#444"));

        Label statusBadge = new Label(associate.getStatus().toString());
        statusBadge.setFont(new Font("Segoe UI Semibold", 12));
        statusBadge.setPadding(new Insets(6, 12, 6, 12));
        String bgColor = uiUtils.getStatusColor(associate.getStatus());
        statusBadge.setStyle("-fx-background-color: " + bgColor + "; -fx-background-radius: 8; -fx-text-fill: white;");

        headerCard.getChildren().addAll(profileIcon, fullName, email, age, statusBadge);
        headerCard.setAlignment(Pos.CENTER);
        contentArea.getChildren().add(headerCard);

        FlowPane cardsContainer = new FlowPane();
        cardsContainer.setHgap(20);
        cardsContainer.setVgap(20);
        cardsContainer.setPadding(new Insets(25, 0, 0, 0));
        cardsContainer.setAlignment(Pos.TOP_CENTER);

        VBox cardEdit = uiUtils.createHomeCard("✏", "Edit Profile",
                "Update your personal information, email, password and more.");
        cardEdit.setPrefWidth(280);
        cardEdit.setMaxWidth(280);
        cardEdit.setOnMouseClicked(_ -> this.showEditProfile(uiUtils, contentArea, scrollPane,
                homeView, membersView, activitiesView, profileView, associate, isAdmin));

        VBox cardActivities = uiUtils.createHomeCard("🏃‍♂️", "My Activities",
                "View the activities you have joined and manage your participation.");
        cardActivities.setPrefWidth(280);
        cardActivities.setMaxWidth(280);
        cardActivities.setOnMouseClicked(_ -> activitiesView.showActivities(uiUtils, contentArea, scrollPane,
                homeView, membersView, activitiesView, profileView, associate, isAdmin));

        VBox cardMembership = uiUtils.createHomeCard("💎", "Membership",
                "Your current membership: " + associate.getStatus());
        cardMembership.setPrefWidth(280);
        cardMembership.setMaxWidth(280);

        VBox cardAdminTools = null;
        if (Boolean.TRUE.equals(isAdmin)) {
            cardAdminTools = uiUtils.createHomeCard("🛠", "Admin Tools",
                    "Manage members, activities and club settings.");
            cardAdminTools.setPrefWidth(280);
            cardAdminTools.setMaxWidth(280);
            cardAdminTools.setOnMouseClicked(_ -> membersView.showManageMembers(uiUtils, contentArea, scrollPane,
                    homeView, membersView, activitiesView, profileView, associate, isAdmin));
        }

        cardsContainer.getChildren().addAll(cardEdit, cardActivities, cardMembership);
        if (cardAdminTools != null) {
            cardsContainer.getChildren().add(cardAdminTools);
        }

        cardsContainer.prefWrapLengthProperty().bind(scrollPane.widthProperty().subtract(40));
        contentArea.getChildren().add(cardsContainer);
        scrollPane.setContent(contentArea);
    }

    /**
     * Renders the profile editing form.
     *
     * <p>This method builds a {@link GridPane} form pre-filled with the user's current data.
     * It includes logic to validate user inputs before saving changes to the object.</p>
     *
     * <p><b>Validation Rules:</b></p>
     * <ul>
     * <li><b>Required Fields:</b> Name, Surname, Email cannot be empty.</li>
     * <li><b>Email:</b> Must match valid email regex and must not be already registered by another user.</li>
     * <li><b>Age:</b> Must be a valid integer between 0 and 150.</li>
     * <li><b>Password:</b> If provided, must meet security complexity requirements (min 8 chars, mixed case, numbers).</li>
     * </ul>
     *
     * @param uiUtils        Utility class for styling and validation.
     * @param contentArea    The container to render the form into.
     * @param scrollPane     The parent scroll container.
     * @param homeView       Navigation reference.
     * @param membersView    Navigation reference.
     * @param activitiesView Navigation reference.
     * @param profileView    Navigation reference (self).
     * @param associate      The user object to be updated.
     * @param isAdmin        Admin flag.
     */
    public void showEditProfile(
            UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane,
            HomeView homeView, MembersView membersView,
            ActivitiesView activitiesView, ProfileView profileView,
            Associate associate, Boolean isAdmin) {

        contentArea.getChildren().clear();

        Label title = new Label("✏️ Edit Profile");
        title.setFont(new Font("Segoe UI Semibold", 20));
        title.setTextFill(Color.web("#0083b0"));
        contentArea.getChildren().add(title);

        GridPane form = new GridPane();
        form.setVgap(10);
        form.setHgap(15);
        form.setPadding(new Insets(20));
        form.setStyle("""
                -fx-background-color: #f9f9f9;
                -fx-background-radius: 10;
                -fx-border-color: #cfd8dc;
                -fx-border-radius: 10;
            """);

        TextField nameField = new TextField(associate.getFirstName());
        TextField surnameField = new TextField(associate.getSurname());
        TextField emailField = new TextField(associate.getEmailAddress());
        TextField ageField = new TextField(String.valueOf(associate.getAge()));
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("New password (optional)");

        uiUtils.styleField(nameField);
        uiUtils.styleField(surnameField);
        uiUtils.styleField(emailField);
        uiUtils.styleField(ageField);
        uiUtils.styleField(passwordField);

        Font labelFont = new Font("Segoe UI Semibold", 14);
        for (Label lbl : new Label[]{new Label("Name:"), new Label("Surname:"), new Label("Email:"),
                new Label("Age:"), new Label("Password:")}) {
            lbl.setFont(labelFont);
            lbl.setTextFill(Color.web("#333"));
        }

        form.addRow(0, new Label("Name:"), nameField);
        form.addRow(1, new Label("Surname:"), surnameField);
        form.addRow(2, new Label("Email:"), emailField);
        form.addRow(3, new Label("Age:"), ageField);
        form.addRow(4, new Label("Password:"), passwordField);

        Button saveBtn = new Button("Save Changes");
        saveBtn.setStyle("-fx-background-color: #00b4db; -fx-text-fill: white; -fx-background-radius: 10;");

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setStyle("-fx-background-color: #ef5350; -fx-text-fill: white; -fx-background-radius: 10;");

        Label msg = new Label();

        saveBtn.setOnAction(_ -> {
            try {
                String name = nameField.getText().trim();
                String surname = surnameField.getText().trim();
                String email = emailField.getText().trim();
                String ageText = ageField.getText().trim();
                String password = passwordField.getText().trim();

                if (name.isEmpty() || surname.isEmpty() || email.isEmpty()) {
                    msg.setText("⚠ Name, surname and email cannot be empty.");
                    msg.setTextFill(Color.RED);
                    return;
                }

                if (!uiUtils.isValidEmail(email)) {
                    msg.setText("⚠ Please enter a valid email address.");
                    msg.setTextFill(Color.RED);
                    return;
                }

                int age;
                try {
                    age = Integer.parseInt(ageText);
                    if (age < 0 || age > 150) {
                        msg.setText("⚠ Age must be between 0 and 150.");
                        msg.setTextFill(Color.RED);
                        return;
                    }
                } catch (NumberFormatException e) {
                    msg.setText("⚠ Age must be a positive number.");
                    msg.setTextFill(Color.RED);
                    return;
                }

                if (!password.isEmpty()) {
                    String passwordError = uiUtils.isValidPassword(password);
                    if (passwordError != null) {
                        msg.setText("⚠ " + passwordError);
                        msg.setTextFill(Color.RED);
                        return;
                    }
                }

                if (!email.equalsIgnoreCase(associate.getEmailAddress())
                        && uiUtils.isEmailAlreadyRegistered(email)) {
                    msg.setText("⚠ This email is already registered by another user.");
                    msg.setTextFill(Color.RED);
                    return;
                }

                associate.setFirstName(name);
                associate.setSurname(surname);
                associate.setEmailAddress(email);
                associate.setAge(age);

                if (!password.isEmpty()) {
                    associate.setPassword(password);
                }

                msg.setText("✅ Profile updated successfully!");
                msg.setTextFill(Color.GREEN);

                this.showProfile(uiUtils, contentArea, scrollPane,
                        homeView, membersView, activitiesView, profileView,
                        associate, isAdmin);

            } catch (Exception ex) {
                msg.setText("⚠ An error occurred while updating profile.");
                msg.setTextFill(Color.RED);
            }
        });

        cancelBtn.setOnAction(_ -> this.showProfile(uiUtils, contentArea, scrollPane,
                homeView, membersView, activitiesView, profileView, associate, isAdmin));

        HBox buttons = new HBox(10, saveBtn, cancelBtn);
        buttons.setAlignment(Pos.CENTER);
        VBox container = new VBox(15, form, buttons, msg);
        container.setAlignment(Pos.CENTER);
        container.setPadding(new Insets(20));

        contentArea.getChildren().add(container);
        scrollPane.setContent(contentArea);
    }
}