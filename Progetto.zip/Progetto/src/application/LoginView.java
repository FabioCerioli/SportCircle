package application;

import java.util.function.Consumer;

import SportCircle.Associate;
import SportCircle.Administrator;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * Manages the graphical user interface for User Authentication (Login) and Registration.
 *
 * 

[Image of user authentication flow chart]

 *
 * <p>The {@code LoginView} serves as the entry point to the application. It provides a
 * unified interface with a tab-like toggle system to switch between:</p>
 * <ul>
 * <li><b>Login Mode:</b> Authenticates existing {@link Associate} or {@link Administrator} accounts against the database.</li>
 * <li><b>Registration Mode:</b> Allows new users to create an account with input validation.</li>
 * </ul>
 *
 * <p>Upon successful authentication, this class invokes a {@link Consumer} callback to transfer
 * control to the main dashboard.</p>
 *
 * @see Database
 */
public class LoginView {

    /** The root container node for the login scene. */
    private BorderPane root;

    /** Callback to execute when a user is successfully authenticated. */
    private Consumer<Associate> onLoginSuccess;

    /**
     * Constructs the LoginView and initializes the UI components.
     *
     * <p>This constructor sets up the main layout, applies the visual theme, and
     * configures the toggle buttons used to switch between the Login and Registration forms.</p>
     */
    public LoginView() {

        root = new BorderPane();
        root.setPadding(Insets.EMPTY);
        root.setStyle("-fx-background-color: #00b4db;");

        Label title = new Label("🏋️‍♂️ Sport Circle");
        title.setFont(new Font("Arial Rounded MT Bold", 32));
        title.setTextFill(Color.WHITE);
        BorderPane.setAlignment(title, Pos.CENTER);
        root.setTop(title);

        VBox container = new VBox(25);
        container.setAlignment(Pos.CENTER);

        // Toggle buttons act as tabs
        ToggleGroup group = new ToggleGroup();
        ToggleButton loginBtn = new ToggleButton("Login");
        ToggleButton registerBtn = new ToggleButton("Register");
        loginBtn.setToggleGroup(group);
        registerBtn.setToggleGroup(group);
        loginBtn.setSelected(true);

        styleToggleButton(loginBtn);
        styleToggleButton(registerBtn);

        HBox tabBar = new HBox(10, loginBtn, registerBtn);
        tabBar.setAlignment(Pos.CENTER);
        tabBar.setPadding(new Insets(10));

        // Content area containing Login and Register forms
        StackPane contentPane = new StackPane();
        Pane loginPane = createLoginPane();
        Pane registerPane = createRegisterPane();
        contentPane.getChildren().addAll(loginPane, registerPane);
        registerPane.setVisible(false);

        loginBtn.setOnAction(_ -> {
            loginPane.setVisible(true);
            registerPane.setVisible(false);
        });

        registerBtn.setOnAction(_ -> {
            loginPane.setVisible(false);
            registerPane.setVisible(true);
        });

        VBox box = new VBox(15, tabBar, contentPane);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(20));
        box.setMaxWidth(400);
        box.setMaxHeight(420);
        box.setStyle("""
                -fx-background-color: white;
                -fx-background-radius: 15;
                -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 10, 0, 0, 5);
            """);

        container.getChildren().add(box);
        root.setCenter(container);
    }

    /**
     * Generates the Login form UI.
     *
     * <p>The login process checks credentials against both the {@link Database#administrators}
     * and {@link Database#associates} lists. It also checks if the account status is locked.</p>
     *
     * @return A {@link Pane} containing email/password fields and the login button.
     */
    private Pane createLoginPane() {
        VBox pane = new VBox(10);
        pane.setAlignment(Pos.CENTER);

        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        styleField(emailField);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        styleField(passwordField);

        Label loginMsg = new Label("Fill all fields");
        loginMsg.setTextFill(Color.BLUE);

        Button loginButton = new Button("Login");
        styleButton(loginButton);

        loginButton.setOnAction(_ -> {
            String email = emailField.getText().trim();
            String pass = passwordField.getText().trim();

            // Missing input
            if (email.isEmpty() || pass.isEmpty()) {
                loginMsg.setText("⚠ Please fill all fields");
                loginMsg.setTextFill(Color.ORANGE);
                return;
            }

            // Try Administrator login
            for (Administrator admin : Database.administrators) {
                if (email.equalsIgnoreCase(admin.getEmailAddress())
                        && (admin.verifyPassword(pass) || pass.equals(admin.getHashedPassword()))) {

                    if (admin.isLocked()) {
                        loginMsg.setText("❌ This account is locked.");
                        loginMsg.setTextFill(Color.RED);
                    } else {
                        if (onLoginSuccess != null) onLoginSuccess.accept(admin);
                    }
                    return;
                }
            }

            // Try Associate login
            for (Associate a : Database.associates) {
                if (email.equalsIgnoreCase(a.getEmailAddress())
                        && (a.verifyPassword(pass) || pass.equals(a.getHashedPassword()))) {

                    if (a.isLocked()) {
                        loginMsg.setText("❌ This account is locked.");
                        loginMsg.setTextFill(Color.RED);
                    } else {
                        if (onLoginSuccess != null) onLoginSuccess.accept(a);
                    }
                    return;
                }
            }

            loginMsg.setText("❌ Invalid credentials");
            loginMsg.setTextFill(Color.RED);
        });

        pane.getChildren().addAll(
                new Label("Email:"), emailField,
                new Label("Password:"), passwordField,
                loginButton, loginMsg
        );
        return pane;
    }

    /**
     * Generates the Registration form UI.
     *
     * <p>This method validates user inputs including:</p>
     * <ul>
     * <li>Format of the email address.</li>
     * <li>Password complexity (length, casing, digits).</li>
     * <li>Uniqueness of the email address in the database.</li>
     * </ul>
     *
     * <p>If validation passes, a new {@link Associate} is created and added to the database.</p>
     *
     * @return A {@link Pane} containing registration fields.
     */
    private Pane createRegisterPane() {
        VBox pane = new VBox(10);
        pane.setAlignment(Pos.CENTER);

        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        styleField(nameField);

        TextField surnameField = new TextField();
        surnameField.setPromptText("Surname");
        styleField(surnameField);

        TextField regEmailField = new TextField();
        regEmailField.setPromptText("Email");
        styleField(regEmailField);

        PasswordField regPasswordField = new PasswordField();
        regPasswordField.setPromptText("Password (min. 8 characters)");
        styleField(regPasswordField);

        Label registerMsg = new Label();

        Button registerButton = new Button("Register");
        styleButton(registerButton);

        registerButton.setOnAction(_ -> {
            String name = nameField.getText().trim();
            String surname = surnameField.getText().trim();
            String email = regEmailField.getText().trim();
            String password = regPasswordField.getText().trim();

            if (name.isEmpty() || surname.isEmpty() || email.isEmpty() || password.isEmpty()) {
                registerMsg.setText("⚠ Please fill all fields");
                registerMsg.setTextFill(Color.ORANGE);
                return;
            }

            if (!isValidEmail(email)) {
                registerMsg.setText("⚠ Invalid email format");
                registerMsg.setTextFill(Color.ORANGE);
                return;
            }

            String passCheck = isValidPassword(password);
            if (passCheck != null) {
                registerMsg.setText("⚠ " + passCheck);
                registerMsg.setTextFill(Color.ORANGE);
                return;
            }

            if (isEmailAlreadyRegistered(email)) {
                registerMsg.setText("⚠ Email is already registered");
                registerMsg.setTextFill(Color.ORANGE);
                return;
            }

            Database.associates.add(new Associate(surname, name, email, password));
            registerMsg.setText("✅ Registration successful!");
            registerMsg.setTextFill(Color.GREEN);

            nameField.clear();
            surnameField.clear();
            regEmailField.clear();
            regPasswordField.clear();
        });

        pane.getChildren().addAll(
                new Label("Name:"), nameField,
                new Label("Surname:"), surnameField,
                new Label("Email:"), regEmailField,
                new Label("Password:"), regPasswordField,
                registerButton, registerMsg
        );

        return pane;
    }

    /**
     * Validates an email string against a standard regex pattern.
     *
     * @param email The email address to check.
     * @return {@code true} if valid, {@code false} otherwise.
     */
    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return email.matches(emailRegex);
    }

    /**
     * Checks if the password meets the security requirements.
     *
     * @param password The password string to check.
     * @return {@code null} if the password is valid, otherwise a String containing the error message.
     */
    private String isValidPassword(String password) {
        if (password.length() < 8)
            return "Password must be at least 8 characters long";
        if (!password.matches(".*[A-Z].*"))
            return "Password must contain one uppercase letter";
        if (!password.matches(".*[a-z].*"))
            return "Password must contain one lowercase letter";
        if (!password.matches(".*\\d.*"))
            return "Password must contain one number";
        return null;
    }

    /**
     * Checks if the email is already in use by an Associate or Administrator.
     *
     * @param email The email address to search for.
     * @return {@code true} if the email exists in the database.
     */
    private boolean isEmailAlreadyRegistered(String email) {
        return (Database.associates.stream().anyMatch(a -> a.getEmailAddress().equalsIgnoreCase(email))
                || Database.administrators.stream().anyMatch(ad -> ad.getEmailAddress().equalsIgnoreCase(email)));
    }

    /**
     * Applies standard styling to text input fields.
     *
     * @param f The TextField to style.
     */
    private void styleField(TextField f) {
        f.setMaxWidth(220);
        f.setPrefWidth(220);
        f.setStyle("""
                -fx-background-radius: 10;
                -fx-border-radius: 10;
                -fx-border-color: #90e0ef;
                -fx-padding: 6;
            """);
    }

    /**
     * Applies standard styling to buttons.
     *
     * @param b The Button to style.
     */
    private void styleButton(Button b) {
        b.setStyle("""
                -fx-background-color: #00b4db;
                -fx-text-fill: white;
                -fx-font-weight: bold;
                -fx-background-radius: 10;
            """);
        b.setPrefWidth(120);
        b.setAlignment(Pos.CENTER);
    }

    /**
     * Applies dynamic styling to ToggleButtons used for tab navigation.
     *
     * @param b The ToggleButton to style.
     */
    private void styleToggleButton(ToggleButton b) {
        b.setStyle("""
                -fx-background-color: #e8f4f8;
                -fx-text-fill: #333;
                -fx-font-weight: bold;
                -fx-background-radius: 10;
            """);
        b.setPrefWidth(120);
        b.setPrefHeight(35);

        b.setOnMouseEntered(_ ->
                b.setStyle("-fx-background-color: #bde0fe; -fx-background-radius: 10;"));
        b.setOnMouseExited(_ -> {
            if (!b.isSelected()) {
                b.setStyle("-fx-background-color: #e8f4f8; -fx-text-fill: #333; -fx-background-radius: 10;");
            }
        });

        b.selectedProperty().addListener((_, _, selected) -> {
            if (selected) {
                b.setStyle("-fx-background-color: #00b4db; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 10;");
            }
        });
    }

    /**
     * Retrieves the root node of the Login View layout.
     *
     * @return The {@link BorderPane} containing the UI.
     */
    public BorderPane getRoot() {
        return root;
    }

    /**
     * Sets the callback to be invoked when authentication is successful.
     *
     * @param callback A consumer that accepts the authenticated {@link Associate}.
     */
    public void setOnLoginSuccess(Consumer<Associate> callback) {
        this.onLoginSuccess = callback;
    }
}