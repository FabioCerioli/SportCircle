package application;

import SportCircle.Associate;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * The entry point for the <b>Sport Circle</b> application.
 *
 * 

[Image of application startup lifecycle]

 *
 * <p>This class extends the JavaFX {@link Application} class and is responsible for
 * the initial bootstrapping of the system. Its primary responsibilities include:</p>
 * <ol>
 * <li><b>Initialization:</b> Setting up the primary stage (window).</li>
 * <li><b>Data Persistence:</b> Loading data from CSV files into the {@link Database} upon startup and saving changes upon shutdown.</li>
 * <li><b>Navigation:</b> Managing the transitions between the {@link LoginView} and the {@link DashboardView}.</li>
 * </ol>
 *
 * <p>The class maintains a static reference to the {@code primaryStage} to facilitate
 * scene switching from other parts of the application.</p>
 *
 * @see Database
 * @see LoginView
 * @see DashboardView
 */
public class Main extends Application {

    /**
     * The primary stage (window) for this application.
     * <p>It is static to allow global access for scene switching (navigation).</p>
     */
    private static Stage primaryStage;

    /**
     * The main entry point for all JavaFX applications.
     *
     * <p>This method is called after the system is ready for the application to begin running.
     * It orchestrates the following startup sequence:</p>
     * <ul>
     * <li>Stores the reference to the primary stage.</li>
     * <li>Invokes {@link Database} methods to load Associates, Administrators, and Activities from disk.</li>
     * <li>Configures the window dimensions and centering.</li>
     * <li>Sets a {@code setOnCloseRequest} handler to ensure data is automatically saved to CSV files when the user closes the app.</li>
     * <li>Navigates to the initial Login screen.</li>
     * </ul>
     *
     * @param stage The primary stage for this application, onto which the application scene can be set.
     */
    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        primaryStage.setTitle("🏋️‍♂️ Sport Circle");

        // Load application data from CSV persistence layer
        Database.loadAssociates();
        Database.loadAdministrators();
        Database.loadActivities();

        // Display the login screen
        showLogin();

        // Configure initial stage size
        primaryStage.centerOnScreen();

        // Register shutdown hook to save data automatically
        stage.setOnCloseRequest(_ -> {
            Database.saveAssociates();
            Database.saveAdministrators();
            Database.saveActivities();
        });
    }

    /**
     * Transitions the application scene to the Login View.
     *
     * <p>This method initializes the {@link LoginView} and defines the callback
     * behavior: upon successful authentication, it triggers the transition to the Dashboard.</p>
     */
    public static void showLogin() {
        LoginView loginView = new LoginView();
        Scene scene = new Scene(loginView.getRoot(), 700, 700);

        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();

        // Define navigation flow: Login -> Dashboard
        loginView.setOnLoginSuccess(associate -> showDashboard(associate));

        primaryStage.show();
    }

    /**
     * Transitions the application scene to the Dashboard View.
     *
     * <p>This method is typically called after a successful login. It initializes
     * the {@link DashboardView} with the specific user's context and maximizes
     * the application window for an optimal experience.</p>
     *
     * @param associate The authenticated {@link Associate} (or Administrator) entering the system.
     */
    public static void showDashboard(Associate associate) {
        DashboardView dash = new DashboardView(associate);
        Scene scene = new Scene(dash.getRoot(), 700, 700);

        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();

        // Maximize window for the main application interface
        primaryStage.setMaximized(true);

        primaryStage.setTitle("Sport Circle - Dashboard");
        primaryStage.show();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be launched
     * through deployment artifacts, e.g., in IDEs with limited FX support.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}