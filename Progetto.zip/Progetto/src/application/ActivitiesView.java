package application;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import SportCircle.Activity;
import SportCircle.ActivityType;
import SportCircle.Associate;
import SportCircle.SportType;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.control.TableRow;

/**
 * Manages the UI logic for displaying and interacting with activities in the SportCircle application.
 *
 * <p>This controller class handles:</p>
 * <ul>
 * <li>Listing available activities with filtering capabilities.</li>
 * <li>Displaying detailed views for specific activities.</li>
 * <li>Managing user subscriptions (join/unsubscribe).</li>
 * <li>Visualizing statistics and user history via charts and tables.</li>
 * <li>Providing AI-driven activity recommendations.</li>
 * <li>Admin functions for creating, editing, and deleting activities.</li>
 * </ul>
 *
 * <p>This class interacts directly with the static {@code Database} to persist changes.</p>
 */
public class ActivitiesView {

    /**
     * Renders the main "Available Activities" screen.
     *
     * <p>This method initializes the header, action buttons, filter bar, and the grid of activity cards.
     * It clears the provided {@code contentArea} before populating it.</p>
     *
     * @param uiUtils        Utility class for UI styling and common operations.
     * @param contentArea    The VBox container where the UI elements will be added.
     * @param scrollPane     The ScrollPane wrapping the content area.
     * @param homeView       Reference to the HomeView for navigation.
     * @param membersView    Reference to the MembersView for navigation.
     * @param activitiesView Reference to this ActivitiesView instance.
     * @param profileView    Reference to the ProfileView for navigation.
     * @param associate      The currently logged-in user.
     * @param isAdmin        Flag indicating if the current user has administrative privileges.
     */
public void showActivities(UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane, HomeView homeView,
            MembersView membersView, ActivitiesView activitiesView, ProfileView profileView, Associate associate,
            Boolean isAdmin) {

    contentArea.getChildren().clear();

    Label title = new Label("🏆 Available Activities");
    title.setFont(new Font("Segoe UI Semibold", 26));
    title.setTextFill(Color.web("#0083b0"));

    Button historyBtn = new Button("📜 History");
    historyBtn.setStyle("""
            -fx-background-color: #00b4db;
            -fx-text-fill: white;
            -fx-background-radius: 10;
            -fx-padding: 8 18;
        """);
    historyBtn.setOnAction(_ -> this.showActivityHistory(uiUtils, contentArea, scrollPane,
            homeView, membersView, activitiesView, profileView, associate, isAdmin));

    Button statsBtn = new Button("📊 Statistics");
    statsBtn.setStyle("""
            -fx-background-color: #4CAF50;
            -fx-text-fill: white;
            -fx-background-radius: 10;
            -fx-padding: 8 18;
        """);
    statsBtn.setOnAction(_ -> this.showActivityStats(uiUtils, contentArea, scrollPane,
            homeView, membersView, activitiesView, profileView, associate, isAdmin));

    Button aiBtn = new Button("🤖 AI Suggestions");
    aiBtn.setStyle("""
            -fx-background-color: #ff9800;
            -fx-text-fill: white;
            -fx-background-radius: 10;
            -fx-padding: 8 18;
        """);
    aiBtn.setOnAction(_ -> this.showAISuggestions(uiUtils, contentArea, scrollPane,
            homeView, membersView, activitiesView, profileView, associate, isAdmin));

    HBox header = new HBox(15, title, historyBtn, statsBtn, aiBtn);
    header.setAlignment(Pos.CENTER_LEFT);
    header.setPadding(new Insets(10, 0, 10, 0));

    Set<String> sportTypes = Database.activities.stream()
            .map(a -> a.getSportType().toString())
            .collect(Collectors.toCollection(TreeSet::new));

    Set<String> activityTypes = Database.activities.stream()
            .map(a -> a.getActivityType().toString())
            .collect(Collectors.toCollection(TreeSet::new));

    ComboBox<String> sportFilter = new ComboBox<>();
    sportFilter.getItems().add("All Sports");
    sportFilter.getItems().addAll(sportTypes);
    sportFilter.getSelectionModel().select(0);
    sportFilter.setStyle(uiUtils.comboBoxStyle);

    ComboBox<String> typeFilter = new ComboBox<>();
    typeFilter.getItems().add("All Activity Types");
    typeFilter.getItems().addAll(activityTypes);
    typeFilter.getSelectionModel().select(0);
    typeFilter.setStyle(uiUtils.comboBoxStyle);

    TextField nameFilter = new TextField();
    nameFilter.setPromptText("🔍 Search...");
    nameFilter.setStyle(uiUtils.textFieldStyle);

    Button applyFilterBtn = new Button("Filter");
    applyFilterBtn.setStyle(uiUtils.primaryButtonStyle);
    applyFilterBtn.setOnMouseEntered(_ -> applyFilterBtn.setStyle("""
            -fx-background-color: linear-gradient(to right, #29c8ea, #0096c7);
            -fx-text-fill: white;
            -fx-background-radius: 12;
            -fx-padding: 8 22;
            -fx-font-size: 14px;
            -fx-font-weight: bold;
        """));

    applyFilterBtn.setOnMouseExited(_ -> applyFilterBtn.setStyle("""
            -fx-background-color: linear-gradient(to right, #00b4db, #0083b0);
            -fx-text-fill: white;
            -fx-background-radius: 12;
            -fx-padding: 8 22;
            -fx-font-size: 14px;
            -fx-font-weight: bold;
        """));
    applyFilterBtn.setOnAction(_ -> {
        applyFilters(uiUtils, contentArea, scrollPane, homeView, membersView,
                activitiesView, profileView, associate, isAdmin,
                sportFilter.getValue(), typeFilter.getValue(), nameFilter.getText().trim());
    });

    HBox filterBar = new HBox(15, sportFilter, typeFilter, nameFilter, applyFilterBtn);
    filterBar.setPadding(new Insets(10, 0, 15, 0));
    filterBar.setAlignment(Pos.CENTER_LEFT);

    contentArea.getChildren().addAll(header, filterBar);

    applyFilters(uiUtils, contentArea, scrollPane,
            homeView, membersView, activitiesView, profileView,
            associate, isAdmin, "All Sports", "All Activity Types", "");
}


    /**
     * Filters the activities based on the selected criteria and updates the UI.
     *
     * <p>This method filters the global {@code Database.activities} list by sport type, activity type,
     * and a name search query. It then rebuilds the card grid.</p>
     *
     * @param uiUtils        Utility class for UI styling.
     * @param contentArea    The container to update.
     * @param scrollPane     The parent scroll pane.
     * @param homeView       Reference to HomeView.
     * @param membersView    Reference to MembersView.
     * @param activitiesView Reference to ActivitiesView.
     * @param profileView    Reference to ProfileView.
     * @param associate      The currently logged-in user.
     * @param isAdmin        Flag indicating admin privileges.
     * @param sportType      The selected sport filter ("All Sports" to ignore).
     * @param activityType   The selected activity type filter ("All Activity Types" to ignore).
     * @param nameQuery      The search string for activity names (empty to ignore).
     */
private void applyFilters(UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane, HomeView homeView,
            MembersView membersView, ActivitiesView activitiesView, ProfileView profileView, Associate associate,
            Boolean isAdmin, String sportType, String activityType, String nameQuery) {

    contentArea.getChildren().removeIf(node -> node instanceof FlowPane);

    List<Activity> filtered = Database.activities.stream()
            .filter(a -> sportType.equals("All Sports")
                    || a.getSportType().toString().equalsIgnoreCase(sportType))
            .filter(a -> activityType.equals("All Activity Types")
                    || a.getActivityType().toString().equalsIgnoreCase(activityType))
            .filter(a -> a.getActivityName().toLowerCase().contains(nameQuery.toLowerCase())
                    || a.getSportType().toString().toLowerCase().contains(nameQuery.toLowerCase())
                    || a.getActivityType().toString().toLowerCase().contains(nameQuery.toLowerCase()))
            .collect(Collectors.toList());

    FlowPane flowPane = new FlowPane();
    flowPane.setHgap(20);
    flowPane.setVgap(20);
    flowPane.setPadding(new Insets(20, 0, 0, 0));
    flowPane.setAlignment(Pos.TOP_CENTER);

    double cardWidth = 300;

    if (filtered.isEmpty()) {
        Label noData = new Label("No activities match the selected filters.");
        noData.setFont(new Font("Segoe UI", 14));
        noData.setTextFill(Color.GRAY);
        contentArea.getChildren().add(noData);
        scrollPane.setContent(contentArea);
        return;
    }

    for (Activity a : filtered) {

        VBox card = new VBox(10);
        card.setPadding(new Insets(18));
        card.setPrefWidth(cardWidth);
        card.setMaxWidth(cardWidth);
        card.setStyle("""
                -fx-background-color: #ffffff;
                -fx-background-radius: 12;
                -fx-border-color: #b3e5fc;
                -fx-border-width: 1;
                -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 10, 0.1, 0, 2);
            """);

        Label name = new Label(a.getActivityName());
        name.setFont(Font.font("Segoe UI Semibold", 16));
        name.setTextFill(Color.web("#0277bd"));

        Label desc = new Label("📅 " + a.getActivityDate() + "    🕒 " + a.getActivityTime());
        desc.setFont(Font.font("Segoe UI", 12));
        desc.setTextFill(Color.web("#555"));

        Label participants = new Label("👥 Participants: " + a.getSubscribed().size());
        participants.setFont(Font.font("Segoe UI", 13));
        participants.setTextFill(Color.web("#555"));

        Button actionBtn = new Button();
        boolean isEnrolled = a.getSubscribed().contains(associate);

        actionBtn.setText(isEnrolled ? "❌ Unsubscribe" : "✅ Join");
        actionBtn.setStyle("-fx-background-color: " + (isEnrolled ? "#ef5350" : "#43a047")
                + "; -fx-text-fill: white; -fx-background-radius: 8; -fx-padding: 6 12;");

        actionBtn.setOnAction(_ -> {
            if (isEnrolled) a.unsubscribeAssociate(associate);
            else a.subscribeAssociate(associate);

            Database.saveActivities();

            applyFilters(uiUtils, contentArea, scrollPane, homeView,
                    membersView, activitiesView, profileView,
                    associate, isAdmin, sportType, activityType, nameQuery);
        });

        card.setOnMouseClicked(_ -> showActivityDetails(a, associate,
                () -> applyFilters(uiUtils, contentArea, scrollPane,
                        homeView, membersView, activitiesView, profileView,
                        associate, isAdmin, sportType, activityType, nameQuery)));

        card.getChildren().addAll(name, desc, participants, actionBtn);
        flowPane.getChildren().add(card);
    }

    contentArea.getChildren().add(flowPane);
    scrollPane.setContent(contentArea);
}


    /**
     * Displays a modal window containing detailed information about a specific activity.
     *
     * <p>The modal shows the activity details, a list of enrolled participants, and allows the user
     * to join or unsubscribe. Upon closing the window, the {@code onClose} runnable is executed to refresh the parent view.</p>
     *
     * @param activity  The activity to display.
     * @param associate The currently logged-in user.
     * @param onClose   A callback to run when the details window is closed.
     */
    public void showActivityDetails(Activity activity, Associate associate, Runnable onClose) {
        Stage detailStage = new Stage();
        detailStage.setTitle("Activity Details");

        VBox layout = new VBox(18);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_LEFT);
        layout.setStyle("""
                    -fx-background-color: linear-gradient(to bottom right, #ffffff, #e3f2fd);
                """);

        Label title = new Label(activity.getActivityName());
        title.setFont(Font.font("Segoe UI Black", 22));
        title.setTextFill(Color.web("#0277bd"));

        Label subtitle = new Label(activity.getSportType() + " • " + activity.getActivityType());
        subtitle.setFont(Font.font("Segoe UI Semibold", 14));
        subtitle.setTextFill(Color.web("#01579b"));

        VBox header = new VBox(4, title, subtitle);

        VBox infoBox = new VBox(8);
        infoBox.setPadding(new Insets(12));
        infoBox.setStyle("""
                    -fx-background-color: white;
                    -fx-background-radius: 10;
                    -fx-border-radius: 10;
                    -fx-border-color: #90caf9;
                    -fx-border-width: 1.2;
                """);

        Label date = new Label("📅 Date: " + activity.getActivityDate());
        Label time = new Label("⏳ Time: " + activity.getActivityTime());
        Label count = new Label("👥 Subscribers: " + activity.getSubscribedCount());

        date.setFont(Font.font("Segoe UI", 14));
        time.setFont(Font.font("Segoe UI", 14));
        count.setFont(Font.font("Segoe UI", 14));

        infoBox.getChildren().addAll(date, time, count);

        boolean isEnrolled = activity.getSubscribed().contains(associate);

        Button joinBtn = new Button(isEnrolled ? "❌ Unsubscribe" : "✅ Join Activity");
        joinBtn.setStyle(isEnrolled
                ? "-fx-background-color: #e53935; -fx-text-fill: white; -fx-background-radius: 8; -fx-padding: 8 16; -fx-font-weight: bold;"
                : "-fx-background-color: #43a047; -fx-text-fill: white; -fx-background-radius: 8; -fx-padding: 8 16; -fx-font-weight: bold;");

        joinBtn.setOnAction(_ -> {
            if (isEnrolled)
                activity.unsubscribeAssociate(associate);
            else
                activity.subscribeAssociate(associate);

            Database.saveActivities();

            detailStage.close();
            onClose.run();
        });

        Label participantsLabel = new Label("📋 Participants");
        participantsLabel.setFont(Font.font("Segoe UI Bold", 16));
        participantsLabel.setTextFill(Color.web("#01579b"));

        VBox membersBox = new VBox(6);
        membersBox.setPadding(new Insets(10));
        membersBox.setStyle("""
                    -fx-background-color: white;
                    -fx-background-radius: 8;
                    -fx-border-radius: 8;
                    -fx-border-color: #bbdefb;
                    -fx-border-width: 1;
                """);

        if (activity.getSubscribedCount() < 1) {
            Label none = new Label("No members enrolled.");
            none.setFont(Font.font("Segoe UI Italic", 13));
            none.setTextFill(Color.GRAY);
            membersBox.getChildren().add(none);
        } else {
            for (Associate a : activity.getSubscribed()) {
                Label member = new Label(
                        "• " + a.getFirstName() + " " + a.getSurname() + "  (" + a.getEmailAddress() + ")");
                member.setFont(Font.font("Segoe UI", 13));
                membersBox.getChildren().add(member);
            }
        }

        ScrollPane scroll = new ScrollPane(membersBox);
        scroll.setFitToWidth(true);
        scroll.setPrefHeight(200);
        scroll.setStyle("-fx-background-color: transparent;");

        Button closeBtn = new Button("Close");
        closeBtn.setStyle("""
                    -fx-background-color: #0288d1;
                    -fx-text-fill: white;
                    -fx-padding: 8 18;
                    -fx-background-radius: 8;
                    -fx-font-size: 14px;
                """);

        closeBtn.setOnAction(_ -> {
            detailStage.close();
            onClose.run();
        });

        HBox bottomBox = new HBox(closeBtn);
        bottomBox.setAlignment(Pos.BOTTOM_RIGHT);
        bottomBox.setPadding(new Insets(10, 0, 0, 0));

        layout.getChildren().addAll(header, infoBox, joinBtn, participantsLabel, scroll, bottomBox);

        Scene scene = new Scene(layout, 420, 520);
        detailStage.setScene(scene);

        detailStage.setOnCloseRequest(_ -> onClose.run());

        detailStage.showAndWait();
    }

    /**
     * Shows a bar chart illustrating participation statistics grouped by sport.
     *
     * <p>This method reads historical data from {@code data/activitiesHistory.csv}, aggregates
     * participant counts by sport, and renders a JavaFX {@code BarChart}.</p>
     *
     * @param uiUtils        Utility class for UI styling.
     * @param contentArea    The container to update.
     * @param scrollPane     The parent scroll pane.
     * @param homeView       Reference to HomeView.
     * @param membersView    Reference to MembersView.
     * @param activitiesView Reference to ActivitiesView.
     * @param profileView    Reference to ProfileView.
     * @param associate      The currently logged-in user.
     * @param isAdmin        Flag indicating admin privileges.
     */
    public void showActivityStats(UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane, HomeView homeView,
            MembersView membersView, ActivitiesView activitiesView, ProfileView profileView, Associate associate,
            Boolean isAdmin) {
        contentArea.getChildren().clear();

        Label title = new Label("📊 Activities Statistics by Sport");
        title.setFont(new Font("Segoe UI Semibold", 20));
        title.setTextFill(Color.web("#0083b0"));

        java.util.List<Activity> activities = new java.util.ArrayList<>();

        try (java.io.BufferedReader reader = new java.io.BufferedReader(
                new java.io.FileReader("data/activitiesHistory.csv"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    String[] parts = line.split(";");
                    if (parts.length >= 6) {
                        String name = parts[0];
                        String sport = parts[1];
                        String type = parts[2];
                        String date = parts[3];
                        String time = parts[4];
                        int participants = parts[5].split(":").length;

                        Activity act = new Activity(name, sport, type, date, time);
                        act.setSubscribedCount(participants);
                        activities.add(act);
                    }
                }
            }
        } catch (Exception e) {
            contentArea.getChildren().add(new Label("⚠ Unable to load activities file."));
            scrollPane.setContent(contentArea);
            return;
        }

        java.util.Map<String, Integer> sportTotals = new java.util.HashMap<>();

        for (Activity a : activities) {
            String sportName = a.getSportType().toString();
            sportTotals.put(sportName, sportTotals.getOrDefault(sportName, 0) + a.getSubscribedCount());
        }

        javafx.scene.chart.CategoryAxis xAxis = new javafx.scene.chart.CategoryAxis();
        xAxis.setLabel("Sport");

        javafx.scene.chart.NumberAxis yAxis = new javafx.scene.chart.NumberAxis();
        yAxis.setLabel("Total Participants");

        javafx.scene.chart.BarChart<String, Number> barChart = new javafx.scene.chart.BarChart<>(xAxis, yAxis);
        barChart.setTitle("Participants per Sport");
        barChart.setLegendVisible(false);

        javafx.scene.chart.XYChart.Series<String, Number> series = new javafx.scene.chart.XYChart.Series<>();

        for (var entry : sportTotals.entrySet()) {
            series.getData().add(new javafx.scene.chart.XYChart.Data<>(entry.getKey(), entry.getValue()));
        }

        barChart.getData().add(series);
        barChart.setCategoryGap(15);
        barChart.setBarGap(5);

        VBox layout = new VBox(20, title, barChart);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        contentArea.getChildren().add(layout);
        scrollPane.setContent(contentArea);
    }

    /**
     * Displays a table history of activities that the current user has participated in.
     *
     * <p>It reads from {@code data/activitiesHistory.csv}, checks if the {@code associate}'s ID
     * is present in the participants list, and displays the matching records in a table.</p>
     *
     * @param uiUtils        Utility class for UI styling.
     * @param contentArea    The container to update.
     * @param scrollPane     The parent scroll pane.
     * @param homeView       Reference to HomeView.
     * @param membersView    Reference to MembersView.
     * @param activitiesView Reference to ActivitiesView.
     * @param profileView    Reference to ProfileView.
     * @param associate      The currently logged-in user used for filtering the history.
     * @param isAdmin        Flag indicating admin privileges.
     */
    @SuppressWarnings("unchecked")
    public void showActivityHistory(UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane, HomeView homeView,
            MembersView membersView, ActivitiesView activitiesView, ProfileView profileView, Associate associate,
            Boolean isAdmin) {

        contentArea.getChildren().clear();

        Label title = new Label("📜 Activities History");
        title.setFont(new Font("Segoe UI Semibold", 22));
        title.setTextFill(Color.web("#0083b0"));

        ComboBox<String> sportFilter = new ComboBox<>();
        sportFilter.setPromptText("Filter by Sport");
        uiUtils.styleComboBox(sportFilter);

        ComboBox<String> typeFilter = new ComboBox<>();
        typeFilter.setPromptText("Filter by Type");
        uiUtils.styleComboBox(typeFilter);

        Button applyBtn = new Button("Apply Filters");
        applyBtn.setStyle("""
                        -fx-background-color: #00b4db;
                        -fx-text-fill: white;
                        -fx-background-radius: 10;
                        -fx-padding: 8 16;
                    """);

        Button resetBtn = new Button("Reset");
        resetBtn.setStyle("""
                        -fx-background-color: #ef5350;
                        -fx-text-fill: white;
                        -fx-background-radius: 10;
                        -fx-padding: 8 16;
                    """);

        Button backBtn = new Button("↩ Back");
        backBtn.setStyle("""
                        -fx-background-color: #888;
                        -fx-text-fill: white;
                        -fx-background-radius: 10;
                        -fx-padding: 8 16;
                    """);
        backBtn.setOnAction(_ -> this.showActivities(uiUtils, contentArea, scrollPane, homeView, membersView,
                activitiesView, profileView, associate, isAdmin));

        HBox filterBar = new HBox(10, sportFilter, typeFilter, applyBtn, resetBtn, backBtn);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        filterBar.setPadding(new Insets(10));

        TableView<String[]> table = new TableView<>();

        table.setStyle("""
                        -fx-background-color: white;
                        -fx-border-color: #b3e5fc;
                        -fx-border-radius: 12;
                        -fx-background-radius: 12;
                    """);

        table.widthProperty().addListener((_, _, _) -> {
            table.lookupAll(".column-header-background").forEach(n -> {
                n.setStyle("""
                                -fx-background-color: linear-gradient(to bottom, #e1f5fe, #b3e5fc);
                                -fx-background-radius: 12 12 0 0;
                            """);
            });
        });

        table.setRowFactory(_ -> new TableRow<>() {
            @Override
            protected void updateItem(String[] item, boolean empty) {
                super.updateItem(item, empty);

                if (empty || item == null) {
                    setStyle("");
                    return;
                }

                int index = getIndex();
                if (index % 2 == 0) {
                    setStyle("-fx-background-color: #f7fbff;");
                } else {
                    setStyle("-fx-background-color: #ffffff;");
                }

                setOnMouseEntered(_ -> setStyle("-fx-background-color: #d9f0ff; -fx-cursor: hand;"));
                setOnMouseExited(_ -> setStyle(
                        index % 2 == 0 ? "-fx-background-color: #f7fbff;" : "-fx-background-color: #ffffff;"));
            }
        });

        java.util.function.Function<String, TableColumn<String[], String>> col = (colName) -> {
            TableColumn<String[], String> c = new TableColumn<>(colName);

            c.setStyle("""
                            -fx-alignment: CENTER-LEFT;
                            -fx-font-size: 14px;
                            -fx-padding: 8 10;
                        """);
            return c;
        };

        TableColumn<String[], String> nameCol = col.apply("Name");
        nameCol.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue()[0]));

        TableColumn<String[], String> sportCol = col.apply("Sport");
        sportCol.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue()[1]));

        TableColumn<String[], String> typeCol = col.apply("Type");
        typeCol.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue()[2]));

        TableColumn<String[], String> dateCol = col.apply("Date");
        dateCol.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue()[3]));

        TableColumn<String[], String> hourCol = col.apply("Hour");
        hourCol.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue()[4]));

        TableColumn<String[], String> participantsCol = col.apply("Participants");
        participantsCol.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue()[5]));

        table.getColumns().addAll(nameCol, sportCol, typeCol, dateCol, hourCol, participantsCol);

        java.util.function.Supplier<java.util.List<String[]>> loadData = () -> {
            java.util.List<String[]> rows = new java.util.ArrayList<>();

            try (java.io.BufferedReader reader = new java.io.BufferedReader(
                    new java.io.FileReader("data/activitiesHistory.csv"))) {

                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.trim().isEmpty())
                        continue;

                    String[] parts = line.split(";");

                    if (parts.length < 6)
                        continue;

                    String participantsRaw = parts[5];
                    boolean userParticipated = false;

                    if (participantsRaw != null && !participantsRaw.isEmpty()) {
                        String[] ids = participantsRaw.split(":");

                        for (String id : ids) {
                            if (id.trim().equalsIgnoreCase(associate.getAssociateId())) {
                                userParticipated = true;
                                break;
                            }
                        }
                    }

                    if (!userParticipated)
                        continue;

                    rows.add(new String[] { parts[0],
                            parts[1],
                            parts[2],
                            parts[3],
                            parts[4],
                            participantsRaw.replace(":", ", ")
                    });
                }

            } catch (Exception e) {
                System.err.println("❌ Error reading activitiesHistory.csv: " + e.getMessage());
            }

            return rows;
        };

        Runnable updateTable = () -> {
            java.util.List<String[]> all = loadData.get();

            if (sportFilter.getItems().isEmpty())
                all.forEach(r -> sportFilter.getItems().add(r[1]));

            if (typeFilter.getItems().isEmpty())
                all.forEach(r -> typeFilter.getItems().add(r[2]));

            javafx.collections.ObservableList<String[]> data = javafx.collections.FXCollections
                    .observableArrayList(all);

            String sportSel = sportFilter.getValue();
            String typeSel = typeFilter.getValue();

            table.setItems(data.filtered(row -> (sportSel == null || sportSel.equals(row[1]))
                    && (typeSel == null || typeSel.equals(row[2]))));
        };

        applyBtn.setOnAction(_ -> updateTable.run());
        resetBtn.setOnAction(_ -> {
            sportFilter.setValue(null);
            typeFilter.setValue(null);
            updateTable.run();
        });

        updateTable.run();

        VBox card = new VBox(15, title, filterBar, table);
        card.setPadding(new Insets(20));
        card.setStyle("""
                        -fx-background-color: #ffffff;
                        -fx-background-radius: 12;
                        -fx-border-color: #b3e5fc;
                        -fx-border-width: 1;
                        -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 10, 0.1, 0, 2);
                    """);

        contentArea.getChildren().add(card);
        scrollPane.setContent(contentArea);
    }

    /**
     * Shows the "Manage Activities" view for administrators.
     *
     * <p>This view allows admins to search, edit, and delete existing activities,
     * as well as adding new ones via the "Add Activity" card.</p>
     *
     * @param uiUtils        Utility class for UI styling.
     * @param contentArea    The container to update.
     * @param scrollPane     The parent scroll pane.
     * @param homeView       Reference to HomeView.
     * @param membersView    Reference to MembersView.
     * @param activitiesView Reference to ActivitiesView.
     * @param profileView    Reference to ProfileView.
     * @param associate      The currently logged-in user.
     * @param isAdmin        Flag indicating admin privileges.
     */
    public void showManageActivities(UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane, HomeView homeView,
            MembersView membersView, ActivitiesView activitiesView, ProfileView profileView, Associate associate,
            Boolean isAdmin) {

        contentArea.getChildren().clear();

        Label title = new Label("🛠 Manage Activities");
        title.setFont(new Font("Segoe UI Semibold", 22));
        title.setTextFill(Color.web("#0083b0"));

        TextField nameFilter = new TextField();
        nameFilter.setPromptText("🔍 Search by name...");
        nameFilter.setStyle(uiUtils.textFieldStyle);

        ComboBox<String> typeFilter = new ComboBox<>();
        typeFilter.getItems().add("All Types");

        Database.activities.stream()
                .map(Activity::getActivityType)
                .distinct()
                .forEach(type -> typeFilter.getItems().add(type.toString()));
        typeFilter.getSelectionModel().select("All Types");
        typeFilter.setStyle(uiUtils.comboBoxStyle);

        ComboBox<String> statusFilter = new ComboBox<>();
        statusFilter.getItems().add("All Status");
        statusFilter.setStyle(uiUtils.comboBoxStyle);

        Button applyFilterBtn = new Button("Apply Filters");
        applyFilterBtn.setStyle(uiUtils.primaryButtonStyle);
        applyFilterBtn.setOnMouseEntered(_ -> applyFilterBtn.setStyle("""
                -fx-background-color: linear-gradient(to right, #29c8ea, #0096c7);
                -fx-text-fill: white;
                -fx-background-radius: 12;
                -fx-padding: 8 22;
                -fx-font-size: 14px;
                -fx-font-weight: bold;
            """));

        applyFilterBtn.setOnMouseExited(_ -> applyFilterBtn.setStyle("""
                -fx-background-color: linear-gradient(to right, #00b4db, #0083b0);
                -fx-text-fill: white;
                -fx-background-radius: 12;
                -fx-padding: 8 22;
                -fx-font-size: 14px;
                -fx-font-weight: bold;
            """));
        HBox filterBar = new HBox(15, new Label("Filters:"), nameFilter, typeFilter, statusFilter, applyFilterBtn);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        filterBar.setPadding(new Insets(10, 0, 20, 0));

        contentArea.getChildren().addAll(title, filterBar);

        @SuppressWarnings("unlikely-arg-type")
        Runnable refresh = () -> {

            contentArea.getChildren().removeIf(node -> node instanceof FlowPane);

            String nameQ = nameFilter.getText().trim().toLowerCase();
            String typeQ = typeFilter.getValue();

            FlowPane flowPane = new FlowPane();
            flowPane.setHgap(20);
            flowPane.setVgap(20);
            flowPane.setPadding(new Insets(20, 0, 0, 0));
            flowPane.setAlignment(Pos.TOP_CENTER);

            Database.activities.stream()
                    .filter(a -> nameQ.isEmpty() || a.getActivityName().toLowerCase().contains(nameQ))
                    .filter(a -> typeQ.equals("All Types") || a.getActivityType().equals(typeQ))
                    .forEach(a -> flowPane.getChildren().add(
                            createActivityCard(a, uiUtils, contentArea, scrollPane, homeView, membersView,
                                    activitiesView, profileView, associate, isAdmin)));

            VBox addActivityCard = createAddActivityCard(uiUtils, contentArea, scrollPane, homeView, membersView,
                    activitiesView, profileView, associate, isAdmin);
            flowPane.getChildren().add(addActivityCard);

            flowPane.prefWrapLengthProperty().bind(scrollPane.widthProperty().subtract(40));

            contentArea.getChildren().add(flowPane);
            scrollPane.setContent(contentArea);
        };

        applyFilterBtn.setOnAction(_ -> refresh.run());

        refresh.run();
    }

    /**
     * Creates a card component representing a single activity in the "Manage" view.
     *
     * <p>Includes buttons to Edit or Delete the activity.</p>
     *
     * @param activity       The activity to represent.
     * @param uiUtils        UI utility class.
     * @param contentArea    The main content area.
     * @param scrollPane     The main scroll pane.
     * @param homeView       HomeView reference.
     * @param membersView    MembersView reference.
     * @param activitiesView ActivitiesView reference.
     * @param profileView    ProfileView reference.
     * @param associate      The current user.
     * @param isAdmin        Admin flag.
     * @return A VBox containing the activity card UI.
     */
    private VBox createActivityCard(Activity activity, UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane,
            HomeView homeView, MembersView membersView, ActivitiesView activitiesView, ProfileView profileView,
            Associate associate, Boolean isAdmin) {
        VBox card = new VBox(12);
        card.setPadding(new Insets(20));
        card.setPrefWidth(300);
        card.setMaxWidth(300);
        card.setStyle("""
                        -fx-background-color: #ffffff;
                        -fx-background-radius: 14;
                        -fx-border-color: #b3e5fc;
                        -fx-border-width: 1;
                        -fx-border-radius: 14;
                        -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 10, 0.15, 0, 2);
                    """);

        card.setOnMouseEntered(_ -> card.setStyle("""
                        -fx-background-color: #e1f5fe;
                        -fx-background-radius: 14;
                        -fx-border-color: #81d4fa;
                        -fx-border-width: 1;
                        -fx-border-radius: 14;
                        -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.25), 12, 0.20, 0, 3);
                    """));

        card.setOnMouseExited(_ -> card.setStyle("""
                        -fx-background-color: #ffffff;
                        -fx-background-radius: 14;
                        -fx-border-color: #b3e5fc;
                        -fx-border-width: 1;
                        -fx-border-radius: 14;
                        -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 10, 0.15, 0, 2);
                    """));

        Label nameLabel = new Label(activity.getActivityName());
        nameLabel.setFont(new Font("Segoe UI Semibold", 16));
        nameLabel.setTextFill(Color.web("#01579b"));
        nameLabel.setWrapText(true);

        Label sportLabel = new Label("🏆 " + activity.getSportType() + " • " + activity.getActivityType());
        sportLabel.setFont(new Font("Segoe UI", 13));
        sportLabel.setTextFill(Color.web("#555"));

        Label dateLabel = new Label("📅 " + activity.getActivityDate());
        dateLabel.setFont(new Font("Segoe UI", 12));
        dateLabel.setTextFill(Color.web("#666"));

        Label timeLabel = new Label("🕒 " + activity.getActivityTime());
        timeLabel.setFont(new Font("Segoe UI", 12));
        timeLabel.setTextFill(Color.web("#666"));

        Label participantsLabel = new Label("👥 Participants: " + activity.getSubscribed().size());
        participantsLabel.setFont(new Font("Segoe UI", 12));
        participantsLabel.setTextFill(Color.web("#666"));

        HBox buttonRow = new HBox(8);
        buttonRow.setAlignment(Pos.CENTER);

        Button editBtn = new Button("✏ Edit");
        editBtn.setStyle(
                "-fx-background-color: #1976d2; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;");

        Button deleteBtn = new Button("🗑 Remove");
        deleteBtn.setStyle(
                "-fx-background-color: #e53935; -fx-text-fill: white; -fx-background-radius: 6; -fx-padding: 6 12;");

        if (isAdmin) {
            card.setOnMouseClicked(_ -> this.showActivityEditor(activity, uiUtils, contentArea, scrollPane, homeView,
                    membersView, activitiesView, profileView, associate, isAdmin));
        }

        editBtn.setOnAction(_ -> this.showActivityEditor(activity, uiUtils, contentArea, scrollPane, homeView,
                membersView, activitiesView, profileView, associate, isAdmin));

        deleteBtn.setOnAction(_ -> {
            Database.activities.remove(activity);
            Database.saveActivities();
            this.showManageActivities(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView,
                    profileView, associate, isAdmin);
        });

        buttonRow.getChildren().addAll(editBtn, deleteBtn);

        card.getChildren().addAll(nameLabel, sportLabel, dateLabel, timeLabel, participantsLabel, buttonRow);
        return card;
    }

    /**
     * Creates a special card that allows the user to add a new activity.
     *
     * @param uiUtils        UI utility class.
     * @param contentArea    The main content area.
     * @param scrollPane     The main scroll pane.
     * @param homeView       HomeView reference.
     * @param membersView    MembersView reference.
     * @param activitiesView ActivitiesView reference.
     * @param profileView    ProfileView reference.
     * @param associate      The current user.
     * @param isAdmin        Admin flag.
     * @return A VBox acting as the "Add New" button card.
     */
    private VBox createAddActivityCard(UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane, HomeView homeView,
            MembersView membersView, ActivitiesView activitiesView, ProfileView profileView, Associate associate,
            Boolean isAdmin) {
        VBox card = new VBox(15);
        card.setPadding(new Insets(25));
        card.setPrefWidth(300);
        card.setMaxWidth(300);
        card.setAlignment(Pos.CENTER);
        card.setStyle("""
                        -fx-background-color: #e8f5e9;
                        -fx-background-radius: 14;
                        -fx-border-color: #a5d6a7;
                        -fx-border-width: 2;
                        -fx-border-radius: 14;
                        -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 10, 0.15, 0, 2);
                    """);

        card.setOnMouseEntered(_ -> card.setStyle("""
                        -fx-background-color: #c8e6c9;
                        -fx-background-radius: 14;
                        -fx-border-color: #81c784;
                        -fx-border-width: 2;
                        -fx-border-radius: 14;
                        -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.25), 12, 0.20, 0, 3);
                    """));

        card.setOnMouseExited(_ -> card.setStyle("""
                        -fx-background-color: #e8f5e9;
                        -fx-background-radius: 14;
                        -fx-border-color: #a5d6a7;
                        -fx-border-width: 2;
                        -fx-border-radius: 14;
                        -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 10, 0.15, 0, 2);
                    """));

        Label icon = new Label("➕");
        icon.setFont(new Font(32));

        Label titleLabel = new Label("Add New Activity");
        titleLabel.setFont(new Font("Segoe UI Semibold", 16));
        titleLabel.setTextFill(Color.web("#2e7d32"));
        titleLabel.setAlignment(Pos.CENTER);

        Label descLabel = new Label("Click to create a new activity");
        descLabel.setFont(new Font("Segoe UI", 12));
        descLabel.setTextFill(Color.web("#555"));
        descLabel.setAlignment(Pos.CENTER);
        descLabel.setWrapText(true);

        VBox contentBox = new VBox(8, icon, titleLabel, descLabel);
        contentBox.setAlignment(Pos.CENTER);

        card.getChildren().add(contentBox);

        card.setOnMouseClicked(_ -> showAddActivityForm(uiUtils, contentArea, scrollPane, homeView, membersView,
                activitiesView, profileView, associate, isAdmin));

        return card;
    }

    /**
     * Opens a modal form to create and save a new activity.
     *
     * <p>Validates inputs (name, type, sport, date, time) before adding the activity to the database.</p>
     *
     * @param uiUtils        UI utility class.
     * @param contentArea    The main content area to refresh.
     * @param scrollPane     The main scroll pane.
     * @param homeView       HomeView reference.
     * @param membersView    MembersView reference.
     * @param activitiesView ActivitiesView reference.
     * @param profileView    ProfileView reference.
     * @param associate      The current user.
     * @param isAdmin        Admin flag.
     */
    private void showAddActivityForm(UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane, HomeView homeView,
            MembersView membersView, ActivitiesView activitiesView, ProfileView profileView, Associate associate,
            Boolean isAdmin) {
        Stage formStage = new Stage();
        formStage.setTitle("Add New Activity");

        VBox formLayout = new VBox(15);
        formLayout.setPadding(new Insets(20));
        formLayout.setAlignment(Pos.CENTER);

        Label formTitle = new Label("➕ Add New Activity");
        formTitle.setFont(new Font("Segoe UI Semibold", 18));
        formTitle.setTextFill(Color.web("#2e7d32"));

        TextField nameField = new TextField();
        nameField.setPromptText("Enter Activity Name");
        uiUtils.styleField(nameField);

        ComboBox<ActivityType> activityTypeBox = new ComboBox<>();
        activityTypeBox.getItems().addAll(ActivityType.values());
        activityTypeBox.setPromptText("Select Activity Type");
        uiUtils.styleComboBox(activityTypeBox);

        ComboBox<SportType> sportTypeBox = new ComboBox<>();
        sportTypeBox.getItems().addAll(SportType.values());
        sportTypeBox.setPromptText("Select Sport Type");
        uiUtils.styleComboBox(sportTypeBox);

        DatePicker datePicker = new DatePicker();
        datePicker.setPromptText("Select Date");
        uiUtils.styleDatePicker(datePicker);

        TextField timeField = new TextField();
        timeField.setPromptText("Enter Time (e.g. 15:30)");
        uiUtils.styleField(timeField);

        Button addBtn = new Button("Add Activity");
        addBtn.setStyle(
                "-fx-background-color: #43a047; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 10; -fx-padding: 8 16;");

        addBtn.setOnAction(_ -> {
            String name = nameField.getText().trim();
            ActivityType selectedActivity = activityTypeBox.getValue();
            SportType selectedSport = sportTypeBox.getValue();
            String date = datePicker.getValue() != null ? datePicker.getValue().toString() : "";
            String time = timeField.getText().trim();

            if (name.isEmpty() || selectedActivity == null || selectedSport == null || date.isEmpty()
                    || time.isEmpty()) {
                uiUtils.showAlert("Error",
                        "Please fill in all fields: name, activity type, sport type, date, and time.");
                return;
            }

            Activity newActivity = new Activity(name, selectedSport.toString(), selectedActivity.toString(), date,
                    time);
            Database.activities.add(newActivity);
            Database.saveActivities();
            formStage.close();
            this.showManageActivities(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView,
                    profileView, associate, isAdmin);
        });

        formLayout.getChildren().addAll(formTitle, nameField, activityTypeBox, sportTypeBox, datePicker, timeField,
                addBtn);

        Scene scene = new Scene(formLayout, 350, 400);
        formStage.setScene(scene);
        formStage.show();
    }

    /**
     * Shows the activity editor, allowing modification of details and participant lists.
     *
     * @param a              The activity to edit.
     * @param uiUtils        UI utility class.
     * @param contentArea    The main content area.
     * @param scrollPane     The main scroll pane.
     * @param homeView       HomeView reference.
     * @param membersView    MembersView reference.
     * @param activitiesView ActivitiesView reference.
     * @param profileView    ProfileView reference.
     * @param associate      The current user.
     * @param isAdmin        Admin flag.
     */
    public void showActivityEditor(Activity a, UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane,
            HomeView homeView, MembersView membersView, ActivitiesView activitiesView, ProfileView profileView,
            Associate associate, Boolean isAdmin) {
        contentArea.getChildren().clear();

        Label title = new Label("⚙ Edit Activity");
        title.setFont(new Font("Segoe UI Semibold", 22));
        title.setTextFill(Color.web("#0083b0"));

        GridPane form = new GridPane();
        form.setVgap(12);
        form.setHgap(15);
        form.setPadding(new Insets(20));
        form.setStyle("""
                        -fx-background-color: #f9f9f9;
                        -fx-background-radius: 10;
                        -fx-border-color: #cfd8dc;
                        -fx-border-radius: 10;
                    """);

        TextField nameField = new TextField(a.getActivityName());
        uiUtils.styleField(nameField);

        ComboBox<ActivityType> activityTypeBox = new ComboBox<>();
        activityTypeBox.getItems().addAll(ActivityType.values());
        if (a.getActivityType() != null && !a.getActivityType().toString().isEmpty()) {
            activityTypeBox.setValue(ActivityType.valueOf(a.getActivityType().toString()));
        }
        uiUtils.styleComboBox(activityTypeBox);

        ComboBox<SportType> sportTypeBox = new ComboBox<>();
        sportTypeBox.getItems().addAll(SportType.values());
        if (a.getSportType() != null && !a.getSportType().toString().isEmpty()) {
            sportTypeBox.setValue(SportType.valueOf(a.getSportType().toString()));
        }
        uiUtils.styleComboBox(sportTypeBox);

        TextField dateField = new TextField(a.getActivityDate());
        dateField.setPromptText("Enter Date (e.g. 2025-11-12)");
        uiUtils.styleField(dateField);

        TextField timeField = new TextField(a.getActivityTime());
        timeField.setPromptText("Enter Time (e.g. 15:30)");
        uiUtils.styleField(timeField);

        form.addRow(0, new Label("Name:"), nameField);
        form.addRow(1, new Label("Activity Type:"), activityTypeBox);
        form.addRow(2, new Label("Sport Type:"), sportTypeBox);
        form.addRow(3, new Label("Date:"), dateField);
        form.addRow(4, new Label("Time:"), timeField);

        Label membersTitle = new Label("👥 Manage Enrolled Members");
        membersTitle.setFont(new Font("Segoe UI Semibold", 18));
        membersTitle.setTextFill(Color.web("#0083b0"));

        VBox membersBox = new VBox(10);
        membersBox.setPadding(new Insets(10));

        VBox enrolledList = new VBox(5);
        uiUtils.updateEnrolledList(enrolledList, a);

        ComboBox<Associate> removeMemberBox = new ComboBox<>();
        removeMemberBox.getItems().addAll(a.getSubscribed());
        removeMemberBox.setPromptText("Select member to remove");
        uiUtils.styleComboBox(removeMemberBox);

        removeMemberBox.setCellFactory(_ -> new ListCell<>() {
            @Override
            protected void updateItem(Associate associate, boolean empty) {
                super.updateItem(associate, empty);
                if (empty || associate == null) {
                    setText(null);
                } else {
                    setText(associate.getFirstName() + " " + associate.getSurname() + " (" + associate.getEmailAddress()
                            + ")");
                }
            }
        });
        removeMemberBox.setButtonCell(removeMemberBox.getCellFactory().call(null));

        Button removeMemberBtn = new Button("🗑 Remove");
        removeMemberBtn.setStyle("-fx-background-color: #e53935; -fx-text-fill: white; -fx-background-radius: 6;");
        removeMemberBtn.setOnAction(_ -> {
            Associate selected = removeMemberBox.getValue();
            if (selected == null) {
                uiUtils.showAlert("Error", "Please select a member to remove.");
                return;
            }
            if (a.unsubscribeAssociate(selected)) {
                Database.saveActivities();
                uiUtils.updateEnrolledList(enrolledList, a);
                removeMemberBox.getItems().setAll(a.getSubscribed());
                removeMemberBox.setValue(null);
            }
        });

        HBox removeBox = new HBox(10, removeMemberBox, removeMemberBtn);

        ComboBox<Associate> addMemberBox = new ComboBox<>();
        addMemberBox.getItems().addAll(Database.associates);
        addMemberBox.getItems().addAll(Database.administrators);
        addMemberBox.setPromptText("Select member to add");
        uiUtils.styleComboBox(addMemberBox);

        addMemberBox.setCellFactory(_ -> new ListCell<>() {
            @Override
            protected void updateItem(Associate associate, boolean empty) {
                super.updateItem(associate, empty);
                if (empty || associate == null) {
                    setText(null);
                } else {
                    setText(associate.getFirstName() + " " + associate.getSurname() + " (" + associate.getEmailAddress()
                            + ")");
                }
            }
        });
        addMemberBox.setButtonCell(addMemberBox.getCellFactory().call(null));

        Button addMemberBtn = new Button("➕ Add");
        addMemberBtn.setStyle("-fx-background-color: #43a047; -fx-text-fill: white; -fx-background-radius: 6;");
        addMemberBtn.setOnAction(_ -> {
            Associate selected = addMemberBox.getValue();
            if (selected == null) {
                uiUtils.showAlert("Error", "Please select a member to add.");
                return;
            }
            a.subscribeAssociate(selected);
            Database.saveActivities();
            uiUtils.updateEnrolledList(enrolledList, a);
            addMemberBox.setValue(null);
            removeMemberBox.getItems().setAll(a.getSubscribed());
        });

        HBox addBox = new HBox(10, addMemberBox, addMemberBtn);

        membersBox.getChildren().addAll(new Label("Add Member:"), addBox, new Label("Remove Member:"), removeBox,
                new Separator(), membersTitle, new Label("Currently Enrolled:"), enrolledList);

        Button saveBtn = new Button("💾 Save Changes");
        saveBtn.setStyle(
                "-fx-background-color: #43a047; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 10; -fx-padding: 8 16;");
        saveBtn.setOnAction(_ -> {
            if (nameField.getText().trim().isEmpty()) {
                uiUtils.showAlert("Error", "Activity name cannot be empty.");
                return;
            }

            a.setActivityName(nameField.getText().trim());
            a.setActivityType(activityTypeBox.getValue() != null ? activityTypeBox.getValue().toString() : "");
            a.setSportType(sportTypeBox.getValue() != null ? sportTypeBox.getValue().toString() : "");
            a.setActivityDate(dateField.getText().trim());
            a.setActivityTime(timeField.getText().trim());

            Database.saveActivities();
            this.showManageActivities(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView,
                    profileView, associate, isAdmin);
        });

        Button cancelBtn = new Button("↩ Back");
        cancelBtn.setStyle(
                "-fx-background-color: #0083b0; -fx-text-fill: white; -fx-background-radius: 10; -fx-padding: 8 16;");
        cancelBtn.setOnAction(_ -> this.showManageActivities(uiUtils, contentArea, scrollPane, homeView, membersView,
                activitiesView, profileView, associate, isAdmin));

        HBox buttons = new HBox(10, saveBtn, cancelBtn);
        buttons.setAlignment(Pos.CENTER_LEFT);
        buttons.setPadding(new Insets(10, 0, 0, 0));

        contentArea.getChildren().addAll(title, form, new Separator(), membersBox, new Separator(), buttons);
        scrollPane.setContent(contentArea);
    }

    /**
     * Displays a view containing "Smart" activity suggestions powered by an AI recommender system.
     *
     * <p>Recommendations are grouped into:</p>
     * <ul>
     * <li>Sports based preferences.</li>
     * <li>Time based preferences.</li>
     * <li>Combined recommendations.</li>
     * </ul>
     *
     * @param uiUtils        UI utility class.
     * @param contentArea    The main content area.
     * @param scrollPane     The main scroll pane.
     * @param homeView       HomeView reference.
     * @param membersView    MembersView reference.
     * @param activitiesView ActivitiesView reference.
     * @param profileView    ProfileView reference.
     * @param associate      The current user.
     * @param isAdmin        Admin flag.
     */
    public void showAISuggestions(UiUtils uiUtils, VBox contentArea, ScrollPane scrollPane, HomeView homeView,
            MembersView membersView, ActivitiesView activitiesView, ProfileView profileView, Associate associate,
            Boolean isAdmin) {

        contentArea.getChildren().clear();

        Label title = new Label("🤖 Smart Activity Suggestions");
        title.setFont(new Font("Segoe UI Semibold", 24));
        title.setTextFill(Color.web("#ff5722"));

        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));

        List<Activity> bySport = ActivityRecommender.recommendBySport(associate);
        List<Activity> byHour = ActivityRecommender.recommendByHour(associate);
        List<Activity> combined = ActivityRecommender.recommendCombined(associate);

        layout.getChildren()
                .addAll(createSuggestionSection("🎯 Based on your favorite Sport", bySport, associate, uiUtils,
                        contentArea, scrollPane, homeView, membersView, activitiesView, profileView, isAdmin),

                        createSuggestionSection("⏰ Based on your preferred Time Range", byHour, associate, uiUtils,
                                contentArea, scrollPane, homeView, membersView, activitiesView, profileView, isAdmin),

                        createSuggestionSection("🔥 Smart Combined Suggestions", combined, associate, uiUtils,
                                contentArea, scrollPane, homeView, membersView, activitiesView, profileView, isAdmin));

        Button backBtn = new Button("↩ Back");
        backBtn.setStyle("-fx-background-color: #888; -fx-text-fill: white; -fx-background-radius: 10;");
        backBtn.setOnAction(_ -> showActivities(uiUtils, contentArea, scrollPane, homeView, membersView, activitiesView,
                profileView, associate, isAdmin));

        layout.getChildren().add(backBtn);

        contentArea.getChildren().add(layout);
        scrollPane.setContent(contentArea);
    }

    /**
     * Creates a UI section displaying a list of recommended activities.
     *
     * @param title          The section title.
     * @param list           The list of activities to display.
     * @param associate      The current user.
     * @param uiUtils        UI utility class.
     * @param contentArea    The main content area.
     * @param scrollPane     The main scroll pane.
     * @param homeView       HomeView reference.
     * @param membersView    MembersView reference.
     * @param activitiesView ActivitiesView reference.
     * @param profileView    ProfileView reference.
     * @param isAdmin        Admin flag.
     * @return A VBox containing the suggestion section.
     */
    private VBox createSuggestionSection(String title, List<Activity> list, Associate associate, UiUtils uiUtils,
            VBox contentArea, ScrollPane scrollPane, HomeView homeView, MembersView membersView,
            ActivitiesView activitiesView, ProfileView profileView, Boolean isAdmin) {

        VBox section = new VBox(15);
        section.setPadding(new Insets(15));

        Label sectionTitle = new Label(title);
        sectionTitle.setFont(new Font("Segoe UI Semibold", 20));
        sectionTitle.setTextFill(Color.web("#ff5722"));

        VBox cards = new VBox(12);

        if (list.isEmpty()) {
            Label l = new Label("No suggestions available yet.");
            l.setFont(new Font(14));
            l.setTextFill(Color.GRAY);
            cards.getChildren().add(l);
        } else {

            for (Activity a : list) {

                HBox card = new HBox(15);
                card.setPadding(new Insets(15));
                card.setAlignment(Pos.CENTER_LEFT);
                card.setStyle("""
                                -fx-background-color: #ffffff;
                                -fx-border-color: #ffccbc;
                                -fx-border-width: 1;
                                -fx-background-radius: 12;
                                -fx-border-radius: 12;
                                -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.10), 10, 0.15, 0, 2);
                            """);

                card.setOnMouseEntered(_ -> card.setStyle("""
                                -fx-background-color: #fff3e0;
                                -fx-border-color: #ff9800;
                                -fx-border-width: 1;
                                -fx-background-radius: 12;
                                -fx-border-radius: 12;
                                -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 10, 0.15, 0, 2);
                            """));

                card.setOnMouseExited(_ -> card.setStyle("""
                                -fx-background-color: #ffffff;
                                -fx-border-color: #ffccbc;
                                -fx-border-width: 1;
                                -fx-background-radius: 12;
                                -fx-border-radius: 12;
                                -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.10), 10, 0.15, 0, 2);
                            """));

                VBox info = new VBox(5);
                Label name = new Label("🏅 " + a.getActivityName());
                name.setFont(new Font("Segoe UI Semibold", 16));

                Label sub = new Label(a.getSportType() + " — " + a.getActivityType() + " — " + a.getActivityTime());
                sub.setFont(new Font(14));
                sub.setTextFill(Color.web("#555"));

                info.getChildren().addAll(name, sub);

                Button joinBtn = new Button();
                Runnable updateBtn = () -> {
                    boolean enrolled = a.getSubscribed().contains(associate);
                    joinBtn.setText(enrolled ? "❌ Unsubscribe" : "✅ Join");
                    joinBtn.setStyle("-fx-background-color: " + (enrolled ? "#ef5350" : "#43a047") +
                            "; -fx-text-fill: white; -fx-background-radius: 8;");
                };

                updateBtn.run();

                joinBtn.setOnAction(_ -> {
                    if (a.getSubscribed().contains(associate))
                        a.unsubscribeAssociate(associate);
                    else
                        a.subscribeAssociate(associate);

                    Database.saveActivities();
                    updateBtn.run();
                });

                card.setOnMouseClicked(
                        _ -> showActivityDetails(a, associate, () -> showAISuggestions(uiUtils, contentArea, scrollPane,
                                homeView, membersView, activitiesView, profileView, associate, isAdmin)));

                card.getChildren().addAll(info, joinBtn);
                cards.getChildren().add(card);
            }
        }

        section.getChildren().addAll(sectionTitle, cards);
        return section;
    }
}