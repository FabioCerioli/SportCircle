package application;

import SportCircle.Activity;
import SportCircle.Associate;
import SportCircle.MemberStatus;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * A shared utility library for enforcing consistent UI styling and behavior across the SportCircle application.
 *
 * 

[Image of styled user interface components]

 *
 * <p>This class acts as a factory and helper for JavaFX components, ensuring uniformity in:</p>
 * <ul>
 * <li><b>Input Validation:</b> Centralized logic for email and password security checks.</li>
 * <li><b>Visual Theming:</b> Standardized CSS styling for form fields, date pickers, and buttons.</li>
 * <li><b>Component Generation:</b> Factory methods for creating interactive dashboard cards.</li>
 * <li><b>Feedback:</b> Helper methods for displaying alerts and error messages.</li>
 * </ul>
 *
 * @see Database
 */
public class UiUtils {

    /**
     * Refreshes a VBox container to display the list of members currently subscribed to an activity.
     *
     * <p>This method clears the existing children of the container and repopulates it.
     * If the subscription list is empty, a placeholder label is displayed.</p>
     *
     * @param enrolledList The {@link VBox} container to be updated.
     * @param a            The {@link Activity} object containing the list of subscribed associates.
     */
    public void updateEnrolledList(VBox enrolledList, Activity a) {
        enrolledList.getChildren().clear();
        if (a.getSubscribed().isEmpty()) {
            enrolledList.getChildren().add(new Label("No members enrolled."));
            return;
        }
        for (Associate m : a.getSubscribed()) {
            Label lbl = new Label("• " + m.getCompleteName() + " (" + m.getEmailAddress() + ")");
            lbl.setFont(new Font("Segoe UI", 13));
            lbl.setTextFill(Color.web("#333"));
            enrolledList.getChildren().add(lbl);
        }
    }

    /**
     * Displays a modal warning alert to the user.
     *
     * <p>Used for validation errors or system warnings. Execution of the calling thread
     * pauses until the user closes the alert.</p>
     *
     * @param title The title text of the alert window.
     * @param msg   The body text of the message.
     */
    public void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    /**
     * Validates if a given string adheres to standard email formatting rules.
     *
     * @param email The string to validate.
     * @return {@code true} if the format is valid, {@code false} otherwise.
     */
    public boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return email.matches(emailRegex);
    }

    /**
     * Validates a password against the application's security policy.
     *
     * <p><b>Policy:</b></p>
     * <ul>
     * <li>Minimum 8 characters.</li>
     * <li>At least one uppercase letter.</li>
     * <li>At least one lowercase letter.</li>
     * <li>At least one numeric digit.</li>
     * </ul>
     *
     * @param password The password string to check.
     * @return {@code null} if the password is valid, otherwise a String describing the specific violation.
     */
    public String isValidPassword(String password) {
        if (password.length() < 8) {
            return "Password must be at least 8 characters long";
        }
        if (!password.matches(".*[A-Z].*")) {
            return "Password must contain at least one uppercase letter";
        }
        if (!password.matches(".*[a-z].*")) {
            return "Password must contain at least one lowercase letter";
        }
        if (!password.matches(".*\\d.*")) {
            return "Password must contain at least one number";
        }
        return null; // null means valid
    }

    /**
     * Checks if the provided email address is already associated with an existing user.
     *
     * <p>This method queries the {@link Database#associates} list.</p>
     *
     * @param email The email address to verify.
     * @return {@code true} if the email exists in the database, {@code false} otherwise.
     */
    public boolean isEmailAlreadyRegistered(String email) {
        return Database.associates.stream()
                .anyMatch(a -> a.getEmailAddress().equalsIgnoreCase(email));
    }

    /**
     * Applies the standard application theme to a TextField.
     *
     * <p>Sets width constraints, padding, border radius, and border colors.</p>
     *
     * @param field The {@link TextField} to style.
     */
    public void styleField(TextField field) {
        field.setMaxWidth(220);
        field.setPrefWidth(220);
        field.setStyle("""
                -fx-background-radius: 10;
                -fx-border-radius: 10;
                -fx-border-color: #90e0ef;
                -fx-padding: 6;
            """);
    }

    /**
     * Applies the standard application theme to a ComboBox.
     *
     * @param comboBox The {@link ComboBox} to style.
     */
    public void styleComboBox(ComboBox<?> comboBox) {
        comboBox.setMaxWidth(220);
        comboBox.setPrefWidth(220);
        comboBox.setStyle("""
                -fx-background-radius: 10;
                -fx-border-radius: 10;
                -fx-border-color: #90e0ef;
                -fx-padding: 6;
                -fx-background-color: white;
            """);
    }

    /**
     * Applies the standard application theme to a DatePicker.
     *
     * @param datePicker The {@link DatePicker} to style.
     */
    public void styleDatePicker(DatePicker datePicker) {
        datePicker.setMaxWidth(220);
        datePicker.setPrefWidth(220);
        datePicker.setStyle("""
                -fx-background-radius: 10;
                -fx-border-radius: 10;
                -fx-border-color: #90e0ef;
                -fx-padding: 6;
                -fx-background-color: white;
            """);
    }

    /**
     * Dynamically styles a ComboBox to reflect the color associated with a {@link MemberStatus}.
     *
     * @param box    The {@link ComboBox} to style.
     * @param status The status determining the background color (e.g., GOLD -> Yellow).
     */
    public void applyStatusColor(ComboBox<MemberStatus> box, MemberStatus status) {
        String color = switch (status) {
            case DIAMOND -> "#b9f2ff";
            case PLATINUM -> "#e5e4e2";
            case GOLD -> "#ffd700";
            case SILVER -> "#c0c0c0";
            default -> "#cd7f32";
        };

        box.setStyle("""
                -fx-background-radius: 6;
                -fx-border-radius: 6;
                -fx-border-color: transparent;
                -fx-text-fill: black;
            """ + "-fx-background-color: " + color + ";");
    }

    /**
     * Factory method to create a standardized interactive card for the Home dashboard.
     *
     * <p>The card is a {@link VBox} containing an icon, title, and description.
     * It includes mouse event listeners to trigger hover effects (shadows and background color changes).</p>
     *
     * @param icon  The string character (emoji or text) acting as the icon.
     * @param title The primary heading of the card.
     * @param desc  The secondary description text.
     * @return A configured {@link VBox} ready to be added to the UI.
     */
    public VBox createHomeCard(String icon, String title, String desc) {
        VBox box = new VBox(8);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(15));
        box.setPrefWidth(180);
        box.setStyle("-fx-background-color: #ffffff; " + "-fx-background-radius: 12; "
                + "-fx-border-color: #b3e5fc; " + "-fx-border-width: 1; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 10, 0.1, 0, 2);");

        Label iconLabel = new Label(icon);
        iconLabel.setFont(Font.font(32));

        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("Segoe UI Semibold", 16));

        Label descLabel = new Label(desc);
        descLabel.setFont(Font.font("Segoe UI", 12));
        descLabel.setTextFill(Color.GRAY);
        descLabel.setWrapText(true);

        box.setOnMouseEntered(_ -> box.setStyle("-fx-background-color: #e1f5fe; " + "-fx-background-radius: 12; "
                + "-fx-border-color: #81d4fa; " + "-fx-border-width: 1; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.25), 12, 0.2, 0, 3);"));

        box.setOnMouseExited(_ -> box.setStyle("-fx-background-color: #ffffff; " + "-fx-background-radius: 12; "
                + "-fx-border-color: #b3e5fc; " + "-fx-border-width: 1; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 10, 0.1, 0, 2);"));

        box.getChildren().addAll(iconLabel, titleLabel, descLabel);

        return box;
    }

    /**
     * Retrieves the hexadecimal color string associated with a specific membership status.
     *
     * @param status The {@link MemberStatus} enum.
     * @return A String representing the hex color (e.g., "#ffd700").
     */
    public String getStatusColor(MemberStatus status) {
        return switch (status) {
            case DIAMOND -> "#b9f2ff";
            case PLATINUM -> "#e5e4e2";
            case GOLD -> "#ffd700";
            case SILVER -> "#c0c0c0";
            default -> "#cd7f32";
        };
    }
    public final String textFieldStyle = """
            -fx-background-color: white;
            -fx-background-radius: 8;
            -fx-border-radius: 8;
            -fx-border-color: #90caf9;
            -fx-border-width: 1;
            -fx-padding: 6 12;
            -fx-prompt-text-fill: #888;
        """;

    public final String comboBoxStyle = """
            -fx-background-color: white;
            -fx-background-radius: 8;
            -fx-border-radius: 8;
            -fx-border-color: #64b5f6;
            -fx-border-width: 1;
            -fx-padding: 4 8;
            -fx-font-size: 13px;
        """;

    public final String primaryButtonStyle = """
            -fx-background-color: #2196f3;
            -fx-text-fill: white;
            -fx-background-radius: 10;
            -fx-padding: 6 16;
            -fx-font-weight: bold;
        """;

}