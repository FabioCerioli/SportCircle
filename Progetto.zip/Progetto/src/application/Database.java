package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

import SportCircle.Activity;
import SportCircle.Administrator;
import SportCircle.Associate;

/**
 * Manages the persistence layer of the SportCircle application.
 *
 * 
 *
 * <p>This class acts as a static data access object (DAO) responsible for synchronizing
 * in-memory data structures (ArrayLists) with physical storage (CSV files).
 * It handles the CRUD operations (specifically Create and Read via loading and saving)
 * for Associates, Administrators, and Activities.</p>
 *
 * <p><b>Data Integrity Note:</b> The loading order is significant. Users (Associates/Admins)
 * should be loaded before Activities to ensure that participant IDs in the activity
 * records can be successfully resolved to existing user objects.</p>
 */
public class Database {

    /** In-memory cache of all registered non-administrative associates. */
    public static ArrayList<Associate> associates = new ArrayList<>();

    /** In-memory cache of all registered system administrators. */
    public static ArrayList<Administrator> administrators = new ArrayList<>();

    /** In-memory cache of all scheduled sport activities. */
    public static ArrayList<Activity> activities = new ArrayList<>();

    /** File system path to the associates data file. */
    private static final String ASSOCIATES_FILE_PATH = "data/associates.csv";

    /** File system path to the administrators data file. */
    private static final String ADMINISTRATORS_FILE_PATH = "data/admins.csv";

    /** File system path to the activities data file. */
    private static final String ACTIVITIES_FILE_PATH = "data/activities.csv";

    /**
     * Reads the associates CSV file and populates the {@code associates} list.
     *
     * <p><b>Expected CSV Format:</b><br>
     * {@code UUID;Surname;FirstName;Email;HashedPassword;Age;Status;SubscriptionDate}</p>
     *
     * <p>Any parsing errors or malformed UUIDs result in the skipping of that specific record,
     * with an error logged to the standard error stream.</p>
     */
    public static void loadAssociates() {
        File file = new File(ASSOCIATES_FILE_PATH);
        if (!file.exists()) {
            System.out.println("⚠ Associates CSV file not found.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            String line;
            while ((line = reader.readLine()) != null) {

                String[] data = line.split(";");
                if (data.length >= 8) {
                    try {
                        UUID associateId = UUID.fromString(data[0]);

                        Associate associate = new Associate(
                                associateId.toString(),
                                data[1],
                                data[2],
                                data[3],
                                "", // Password placeholder, set below
                                Integer.parseInt(data[5]),
                                data[6],
                                data[7]
                        );

                        associate.setPasswordAlreadyHashed(data[4]);
                        associates.add(associate);

                    } catch (IllegalArgumentException exception) {
                        System.err.println("⚠ Invalid UUID in associates CSV: " + data[0]);
                    }
                }
            }

        } catch (IOException exception) {
            System.err.println("❌ Error reading associates CSV file");
            exception.printStackTrace();
        }
    }

    /**
     * Reads the administrators CSV file and populates the {@code administrators} list.
     *
     * <p><b>Expected CSV Format:</b><br>
     * {@code UUID;Surname;FirstName;Email;HashedPassword;Age;Status;SubscriptionDate}</p>
     *
     * <p>Similar to {@link #loadAssociates()}, invalid records are skipped and logged.</p>
     */
    public static void loadAdministrators() {
        File file = new File(ADMINISTRATORS_FILE_PATH);
        if (!file.exists()) {
            System.out.println("⚠ Administrators CSV file not found.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            String line;
            while ((line = reader.readLine()) != null) {

                String[] data = line.split(";");
                if (data.length >= 8) {
                    try {
                        UUID administratorId = UUID.fromString(data[0]);

                        Administrator administrator = new Administrator(
                                administratorId.toString(),
                                data[1],
                                data[2],
                                data[3],
                                "",
                                Integer.parseInt(data[5]),
                                data[6],
                                data[7]
                        );

                        administrator.setPasswordAlreadyHashed(data[4]);
                        administrators.add(administrator);

                    } catch (IllegalArgumentException exception) {
                        System.err.println("⚠ Invalid UUID in administrators CSV: " + data[0]);
                    }
                }
            }

        } catch (IOException exception) {
            System.err.println("❌ Error reading administrators CSV file");
            exception.printStackTrace();
        }
    }

    /**
     * Reads the activities CSV file and populates the {@code activities} list.
     *
     * <p><b>Expected CSV Format:</b><br>
     * {@code Name;SportType;ActivityType;Date;Time;ParticipantID1:ParticipantID2:...}</p>
     *
     * <p>This method attempts to resolve participant IDs (index 5) by looking them up
     * in the loaded {@code associates} and {@code administrators} lists via
     * {@link #findParticipantById(String)}. If a user ID is found, the User object
     * is subscribed to the activity.</p>
     */
    public static void loadActivities() {
        File file = new File(ACTIVITIES_FILE_PATH);
        if (!file.exists()) {
            System.out.println("⚠ Activities CSV file not found.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            String line;
            while ((line = reader.readLine()) != null) {

                String[] data = line.split(";");
                if (data.length >= 5) {

                    Activity activity = new Activity(
                            data[0],
                            data[1],
                            data[2],
                            data[3],
                            data[4]
                    );

                    // Parse participants if they exist (Index 5)
                    if (data.length >= 6 && data[5] != null && !data[5].isEmpty()) {
                        String[] participantIds = data[5].split(":");

                        for (String id : participantIds) {
                            Associate found = findParticipantById(id.trim());
                            if (found != null) {
                                if (!activity.getSubscribed().contains(found)) {
                                    activity.subscribeAssociate(found);
                                }
                            } else {
                                System.err.println("⚠ ID not found: " + id);
                            }
                        }
                    }

                    activities.add(activity);
                }
            }

        } catch (IOException exception) {
            System.err.println("❌ Error reading activities CSV file");
            exception.printStackTrace();
        }
    }

    /**
     * Helper method to locate a user by their unique ID.
     *
     * <p>The search is performed first in the {@code associates} list, and if not found,
     * in the {@code administrators} list.</p>
     *
     * @param participantId The String representation of the UUID to find.
     * @return The {@link Associate} (or Administrator) object if found, otherwise {@code null}.
     */
    private static Associate findParticipantById(String participantId) {

        for (Associate associate : associates)
            if (associate.getAssociateId().equalsIgnoreCase(participantId))
                return associate;

        for (Administrator administrator : administrators)
            if (administrator.getAssociateId().equalsIgnoreCase(participantId))
                return administrator;

        return null;
    }

    /**
     * Serializes the current state of the {@code associates} list to the CSV file.
     *
     * <p>This operation overwrites the existing file.</p>
     */
    public static void saveAssociates() {
        try (FileWriter writer = new FileWriter(ASSOCIATES_FILE_PATH, false)) {

            for (Associate associate : associates) {
                writer.write(
                        associate.getAssociateId() + ";" +
                                associate.getSurname() + ";" +
                                associate.getFirstName() + ";" +
                                associate.getEmailAddress() + ";" +
                                associate.getHashedPassword() + ";" +
                                associate.getAge() + ";" +
                                associate.getStatusToString() + ";" +
                                associate.getDateOfSubscription() + "\n"
                );
            }

        } catch (IOException exception) {
            System.err.println("❌ Error saving associates CSV file");
            exception.printStackTrace();
        }
    }

    /**
     * Serializes the current state of the {@code administrators} list to the CSV file.
     *
     * <p>This operation overwrites the existing file.</p>
     */
    public static void saveAdministrators() {
        try (FileWriter writer = new FileWriter(ADMINISTRATORS_FILE_PATH, false)) {

            for (Administrator administrator : administrators) {
                writer.write(
                        administrator.getAssociateId() + ";" +
                                administrator.getSurname() + ";" +
                                administrator.getFirstName() + ";" +
                                administrator.getEmailAddress() + ";" +
                                administrator.getHashedPassword() + ";" +
                                administrator.getAge() + ";" +
                                administrator.getStatusToString() + ";" +
                                administrator.getDateOfSubscription() + "\n"
                );
            }

        } catch (IOException exception) {
            System.err.println("❌ Error saving administrators CSV file");
            exception.printStackTrace();
        }
    }

    /**
     * Serializes the current state of the {@code activities} list to the CSV file.
     *
     * <p>The participants list for each activity is converted into a single string
     * where individual user IDs are separated by colons ({@code :}).</p>
     *
     * <p>This operation overwrites the existing file.</p>
     */
    public static void saveActivities() {
        try (FileWriter writer = new FileWriter(ACTIVITIES_FILE_PATH, false)) {

            for (Activity activity : activities) {

                StringBuilder participantsBuilder = new StringBuilder();
                for (Associate participant : activity.getSubscribed()) {
                    participantsBuilder.append(participant.getAssociateId()).append(":");
                }

                String participants = participantsBuilder.toString();
                if (participants.endsWith(":"))
                    participants = participants.substring(0, participants.length() - 1);

                writer.write(
                        activity.getActivityName() + ";" +
                                activity.getSportType() + ";" +
                                activity.getActivityType() + ";" +
                                activity.getActivityDate() + ";" +
                                activity.getActivityTime() + ";" +
                                participants + "\n"
                );
            }

        } catch (IOException exception) {
            System.err.println("❌ Error saving activities CSV file");
            exception.printStackTrace();
        }
    }
}