package application;

import SportCircle.*;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * Represents the primary user interface container for the SportCircle application.
 *
 * <p>The Dashboard implements a standard application layout using a {@link BorderPane}:</p>
 * <ul>
 * <li><b>Left Region:</b> Contains the persistent navigation sidebar ({@link #createSideMenu()}).</li>
 * <li><b>Center Region:</b> Contains a scrollable {@link VBox} where dynamic content is loaded (Home, Activities, Profile, etc.).</li>
 * </ul>
 *
 * <p>Upon initialization, this view determines if the logged-in {@link Associate} is an
 * {@link Administrator} to conditionally render privileged menu options.</p>
 *
 * @see HomeView
 * @see ActivitiesView
 * @see MembersView
 * @see ProfileView
 */
public class DashboardView {

    /** The currently authenticated user session. */
    private Associate associate;

    /** Helper class for consistent UI styling across the application. */
    UiUtils uiUtils = new UiUtils();

    /** View controller for the landing page. */
    HomeView homeView = new HomeView();

    /** View controller for the member directory. */
    MembersView membersView = new MembersView();

    /** View controller for activity listings and management. */
    ActivitiesView activitiesView = new ActivitiesView();

    /** View controller for user profile management. */
    ProfileView profileView = new ProfileView();

    /** Flag indicating if the current user has administrative privileges. */
    private boolean isAdmin;

    /** The main layout container for the scene. */
    private BorderPane root;

    /** The dynamic container where view content is injected. */
    private VBox contentArea;

    /** The scroll wrapper ensuring content accessibility on smaller screens. */
    private ScrollPane scrollPane;

    /**
     * Constructs the Dashboard view and initializes the user interface.
     *
     * <p>This constructor performs the following setup steps:</p>
     * <ol>
     * <li>Determines if the passed {@link Associate} is an instance of {@link Administrator}.</li>
     * <li>Initializes the main layout containers (BorderPane, ScrollPane, VBox).</li>
     * <li>Generates the side navigation menu.</li>
     * <li>Automatically loads the {@link HomeView} as the default starting screen.</li>
     * </ol>
     *
     * @param a The currently logged-in {@link Associate}.
     */
    public DashboardView(Associate a) {
        this.associate = a;
        this.isAdmin = (a instanceof Administrator);

        root = new BorderPane();
        scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);

        contentArea = new VBox(10);
        contentArea.setPadding(new Insets(20));

        scrollPane.setContent(contentArea);

        root.setLeft(createSideMenu());
        root.setCenter(scrollPane);

        homeView.showHome(
                uiUtils, contentArea, scrollPane,
                homeView, membersView, activitiesView, profileView,
                associate, isAdmin
        );
    }

    /**
     * Retrieves the root node of the dashboard layout.
     *
     * <p>This method is typically called by the {@link Main} class to set the scene's root.</p>
     *
     * @return The main {@link BorderPane} containing the dashboard UI.
     */
    public BorderPane getRoot() {
        return root;
    }

    /**
     * Generates the sidebar navigation menu.
     *
     * <p>The menu consists of styled buttons that switch the content displayed in the center area.
     * If the {@code isAdmin} flag is true, a special "Admin Area" section is appended to the menu,
     * granting access to {@code Manage Members} and {@code Manage Activities}.</p>
     *
     * @return A {@link VBox} containing the styled navigation buttons.
     */
    private VBox createSideMenu() {
        VBox menu = new VBox(15);
        menu.setPadding(new Insets(30, 15, 30, 15));
        menu.setPrefWidth(200);
        menu.setStyle("-fx-background-color: #e3f2fd; -fx-border-color: #b3e5fc; -fx-border-width: 0 1 0 0;");

        Button homeBtn = createMenuButton("🏠 Home");
        homeBtn.setOnAction(_ -> homeView.showHome(
                uiUtils, contentArea, scrollPane,
                homeView, membersView, activitiesView, profileView,
                associate, isAdmin
        ));

        Button activitiesBtn = createMenuButton("🏆 Activities");
        Button membersBtn = createMenuButton("👥 Members");
        Button profileBtn = createMenuButton("👤 Profile");
        Button logoutBtn = createMenuButton("🚪 Logout");

        activitiesBtn.setOnAction(_ -> activitiesView.showActivities(
                uiUtils, contentArea, scrollPane,
                homeView, membersView, activitiesView, profileView,
                associate, isAdmin
        ));
        membersBtn.setOnAction(_ -> membersView.showMembers(
                uiUtils, contentArea, scrollPane,
                homeView, membersView, activitiesView, profileView,
                associate, isAdmin
        ));
        profileBtn.setOnAction(_ -> profileView.showProfile(
                uiUtils, contentArea, scrollPane,
                homeView, membersView, activitiesView, profileView,
                associate, isAdmin
        ));
        logoutBtn.setOnAction(_ -> Main.showLogin());

        menu.getChildren().add(homeBtn);
        menu.getChildren().addAll(activitiesBtn, membersBtn, profileBtn);

        // Admin-only section
        if (isAdmin) {
            Label adminLabel = new Label("— Admin Area —");
            adminLabel.setTextFill(Color.web("#0083b0"));
            adminLabel.setFont(new Font("Segoe UI Semibold", 13));

            Button manageMembersBtn = createMenuButton("👑 Manage Members");
            Button manageActivitiesBtn = createMenuButton("🛠 Manage Activities");

            manageMembersBtn.setOnAction(_ -> membersView.showManageMembers(
                    uiUtils, contentArea, scrollPane,
                    homeView, membersView, activitiesView, profileView,
                    associate, isAdmin
            ));

            manageActivitiesBtn.setOnAction(_ -> activitiesView.showManageActivities(
                    uiUtils, contentArea, scrollPane,
                    homeView, membersView, activitiesView, profileView,
                    associate, isAdmin
            ));

            menu.getChildren().addAll(adminLabel, manageMembersBtn, manageActivitiesBtn);
        }

        menu.getChildren().add(logoutBtn);
        return menu;
    }

    /**
     * Creates a standardized navigation button with hover effects.
     *
     * <p>This helper method ensures all sidebar buttons share the same aesthetic properties,
     * such as transparent backgrounds by default and light blue backgrounds on mouse hover.</p>
     *
     * @param text The label text to display on the button.
     * @return A styled {@link Button} ready for the side menu.
     */
    private Button createMenuButton(String text) {
        Button btn = new Button(text);
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setStyle("-fx-background-color: transparent; -fx-font-size: 14; -fx-text-fill: #333;");

        btn.setOnMouseEntered(
                _ -> btn.setStyle("-fx-background-color: #bbdefb; -fx-font-size: 14; -fx-text-fill: #000;")
        );

        btn.setOnMouseExited(
                _ -> btn.setStyle("-fx-background-color: transparent; -fx-font-size: 14; -fx-text-fill: #333;")
        );

        return btn;
    }
}