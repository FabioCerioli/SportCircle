package SportCircle;

import java.util.ArrayList;
import java.util.UUID;

/**
 * Represents a system user with elevated administrative privileges.
 *
 * 
 *
 * <p>The {@code Administrator} extends the capabilities of a standard {@link Associate}.
 * While retaining standard user features, an Administrator possesses the authority to:</p>
 * <ul>
 * <li><b>Manage Users:</b> Create, modify profile details, and delete other associates.</li>
 * <li><b>Manage Activities:</b> Schedule new events, alter their types, or cancel them.</li>
 * <li><b>Manage Subscriptions:</b> Manually force the subscription of an associate to an activity.</li>
 * </ul>
 *
 * @see Associate
 * @see Activity
 */
public class Administrator extends Associate {

    /**
     * Constructs a new Administrator with basic credentials and generates a unique system ID.
     *
     * <p>This constructor is typically used when registering a new admin for the first time.</p>
     *
     * @param surname           The administrator's last name.
     * @param firstName         The administrator's first name.
     * @param emailAddress      The unique email address.
     * @param plainTextPassword The raw password (to be hashed by the parent class).
     */
    public Administrator(String surname, String firstName, String emailAddress, String plainTextPassword) {
        setAssociateId(UUID.randomUUID().toString());
        setSurname(surname);
        setFirstName(firstName);
        setEmailAddress(emailAddress);
        setPassword(plainTextPassword);
    }

    /**
     * Reconstructs an Administrator object using an existing unique ID.
     *
     * <p>This is commonly used when loading admin data from a simplified storage format.</p>
     *
     * @param associateId       The pre-existing unique UUID.
     * @param surname           The administrator's last name.
     * @param firstName         The administrator's first name.
     * @param emailAddress      The email address.
     * @param plainTextPassword The raw password.
     */
    public Administrator(String associateId, String surname, String firstName, String emailAddress,
                         String plainTextPassword) {
        setAssociateId(associateId);
        setSurname(surname);
        setFirstName(firstName);
        setEmailAddress(emailAddress);
        setPassword(plainTextPassword);
    }

    /**
     * Constructs a fully populated Administrator object.
     *
     * <p>This constructor is intended for complete deserialization from the database (CSV),
     * ensuring all state fields (including age, status, and subscription date) are restored correctly.</p>
     *
     * @param associateId       The unique UUID.
     * @param surname           The last name.
     * @param firstName         The first name.
     * @param emailAddress      The email address.
     * @param plainTextPassword The raw password (note: if loading from DB, this might be overwritten by setPasswordAlreadyHashed).
     * @param age               The administrator's age.
     * @param status            The string representation of the {@link MemberStatus}.
     * @param date              The date of account creation.
     */
    public Administrator(String associateId, String surname, String firstName, String emailAddress,
                         String plainTextPassword, int age, String status, String date) {
        setAssociateId(associateId);
        setSurname(surname);
        setFirstName(firstName);
        setEmailAddress(emailAddress);
        setPassword(plainTextPassword);
        setAge(age);
        setStatus(status);
        setDateOfSubscription(date);
    }

    /**
     * Default constructor for creating an empty Administrator instance.
     */
    public Administrator() {
    }

    /**
     * Manually subscribes a specific associate to an activity.
     *
     * <p>This bypasses standard self-enrollment flows, allowing admins to manage
     * bookings on behalf of users.</p>
     *
     * @param activity  The target {@link Activity}.
     * @param associate The {@link Associate} to be enrolled.
     * @return {@code true} if the subscription was successful, {@code false} if already subscribed.
     */
    public boolean addAssociateToActivity(Activity activity, Associate associate) {
        return activity.subscribeAssociate(associate);
    }

    /**
     * Registers a new associate in the system list.
     *
     * @param associateList The master list of all associates.
     * @param associate     The new {@link Associate} object to add.
     * @return {@code true} if added successfully, {@code false} if the associate is already in the list.
     */
    public boolean createAssociate(ArrayList<Associate> associateList, Associate associate) {
        if (!associateList.contains(associate)) {
            associateList.add(associate);
            return true;
        }
        return false;
    }

    /**
     * Modifies a specific profile field of an existing associate.
     *
     * @param associate The {@link Associate} whose data needs modification.
     * @param fieldType The name of the field to edit. Valid values are:
     * <ul>
     * <li>"surname"</li>
     * <li>"firstname" or "name"</li>
     * <li>"email"</li>
     * <li>"password"</li>
     * </ul>
     * @param newValue  The new value to assign to the field.
     * @return {@code true} if the field was valid and updated, {@code false} otherwise.
     */
    public boolean modifyAssociate(Associate associate, String fieldType, String newValue) {
        fieldType = fieldType.toLowerCase();
        switch (fieldType) {
            case "surname" -> associate.setSurname(newValue);
            case "firstname", "name" -> associate.setFirstName(newValue);
            case "email" -> associate.setEmailAddress(newValue);
            case "password" -> associate.setPassword(newValue);
            default -> {
                return false;
            }
        }
        return true;
    }

    /**
     * Permanently removes an associate from the system.
     *
     * <p><b>Side Effect:</b> This method first iterates through all activities to unsubscribe
     * the associate, ensuring no dangling references remain in activity participant lists.</p>
     *
     * @param activityList  The master list of all activities.
     * @param associateList The master list of all associates.
     * @param associate     The {@link Associate} to remove.
     * @return {@code true} if the associate was found and removed, {@code false} otherwise.
     */
    public boolean deleteAssociate(ArrayList<Activity> activityList, ArrayList<Associate> associateList,
                                   Associate associate) {
        if (associateList.contains(associate)) {
            for (Activity activity : activityList) {
                activity.unsubscribeAssociate(associate);
            }
            associateList.remove(associate);
            return true;
        }
        return false;
    }

    /**
     * Schedules a new activity in the system.
     *
     * @param activityList The master list of all activities.
     * @param activity     The new {@link Activity} to schedule.
     * @return {@code true} if added successfully, {@code false} if it already exists.
     */
    public boolean createActivity(ArrayList<Activity> activityList, Activity activity) {
        if (!activityList.contains(activity)) {
            activityList.add(activity);
            return true;
        }
        return false;
    }

    /**
     * Modifies the categorization (Sport or Type) of an existing activity.
     *
     * <p>This method attempts to map the {@code newValue} string to the corresponding
     * {@link SportType} or {@link ActivityType} enum.</p>
     *
     * @param activity  The {@link Activity} to update.
     * @param fieldType The property to change: "sporttype"/"sport" or "activitytype"/"type".
     * @param newValue  The string representation of the new enum value.
     * @return {@code true} if the modification was successful, {@code false} if the field
     * was invalid or the enum value could not be found (sets Type to NULL in failure case).
     */
    public boolean modifyActivity(Activity activity, String fieldType, String newValue) {
        fieldType = fieldType.toLowerCase();
        newValue = newValue.toUpperCase();

        switch (fieldType) {
            case "sporttype", "sport" -> {
                for (SportType sportType : SportType.values()) {
                    if (sportType.toString().equals(newValue)) {
                        activity.setSportType(sportType);
                        return true;
                    }
                }
                return false;
            }
            case "activitytype", "type" -> {
                for (ActivityType activityType : ActivityType.values()) {
                    if (activityType.toString().equals(newValue)) {
                        activity.setActivityType(activityType);
                        return true;
                    }
                }
                activity.setActivityType(ActivityType.NULL);
                return false;
            }
            default -> {
                return false;
            }
        }
    }

    /**
     * Cancels and removes an activity from the system.
     *
     * @param activityList The master list of activities.
     * @param activity     The {@link Activity} to remove.
     * @return {@code true} if removed successfully, {@code false} otherwise.
     */
    public boolean deleteActivity(ArrayList<Activity> activityList, Activity activity) {
        if (activityList.contains(activity)) {
            activityList.remove(activity);
            return true;
        }
        return false;
    }
}