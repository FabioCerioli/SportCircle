package SportCircle;

/**
 * Defines the specific format or category of a sporting {@link Activity}.
 *
 * 
 *
 * <p>This enumeration is used to categorize events in the schedule, allowing users
 * to filter activities based on their nature (e.g., distinguishing between a
 * competitive {@code MATCH} and an instructional {@code LESSON}).</p>
 *
 * @see Activity
 */
public enum ActivityType {

    /**
     * An instructional session led by a coach or instructor aimed at teaching specific skills.
     */
    LESSON,

    /**
     * A practice session focused on physical conditioning, drills, or team strategy.
     */
    TRAINING,

    /**
     * A standard competitive game between two entities (individuals or teams).
     */
    MATCH,

    /**
     * A structured competition involving multiple matches, rounds, and participants.
     */
    TOURNAMENT,

    /**
     * A general social gathering, promotional occasion, or special celebration.
     */
    EVENT,

    /**
     * An intensive, short-term educational session focusing on a specific topic or technique.
     */
    WORKSHOP,

    /**
     * A multi-day immersive program, often involving training and accommodation.
     */
    CAMP,

    /**
     * A formal contest where participants are ranked based on performance.
     */
    COMPETITION,

    /**
     * A game played for leisure or practice without official ranking implications.
     */
    FRIENDLY,

    /**
     * An administrative or organizational gathering for members or staff.
     */
    MEETING,

    /**
     * Represents an undefined, uninitialized, or invalid activity type.
     */
    NULL
}