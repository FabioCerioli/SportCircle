package SportCircle;

/**
 * The abstract base class for all domain entities within the SportCircle system.
 *
 * 
 *
 * <p>This class establishes a common contract for all major system objects
 * (such as {@link Associate}, {@link Administrator}, and {@link Activity}).
 * It ensures that every entity implements standard methods for data serialization
 * and debugging.</p>
 */
public abstract class Item {

    /**
     * Retrieves a formatted string representation of the entity's primary data.
     *
     * <p>Subclasses should override this method to provide a specific format suitable
     * for file storage (CSV) or user interface display.</p>
     *
     * @return A string containing the core data of the item.
     */
    String getDataToString() {
        return "This is a standard output";
    }

    /**
     * Retrieves a detailed string representation intended for debugging and logging purposes.
     *
     * <p>This string typically includes internal identifiers, hashed passwords, or
     * other sensitive/technical data not meant for general display.</p>
     *
     * @return A string containing debug information.
     */
    String getStringDebug() {
        return "This is a standard debug";
    }
}