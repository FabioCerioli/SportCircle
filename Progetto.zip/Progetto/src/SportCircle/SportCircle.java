package SportCircle;

import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;

/**
 * The main driver class for the Sport Circle management system.
 *
 * 

[Image of SportCircle system architecture diagram]

 *
 * <p>This class serves as the central hub for executing system operations. Its primary responsibilities include:</p>
 * <ul>
 * <li><b>File I/O:</b> Managing input data paths and writing system logs/outputs to a text file.</li>
 * <li><b>Data Reporting:</b> providing a polymorphic method {@link #printArrayList(ArrayList)} to display lists of different entities (Associates, Admins, Activities).</li>
 * <li><b>System Initialization:</b> Resetting logs and starting the application flow.</li>
 * </ul>
 *
 * @author Cerioli Fabio: 360935
 * @see Item
 * @see Administrator
 * @see Associate
 * @see Activity
 */
public class SportCircle {

    /**
     * File path for the system's initial data input.
     */
    static String fileInput = "dataInput.txt";

    /**
     * File path for the system's operational log output.
     */
    static String fileOutput = "PrintOutput.txt";

    /**
     * Appends a single line of text to the defined output file.
     *
     * <p>This method opens the file in append mode. If an I/O error occurs,
     * the exception is caught, and an error message is printed to the standard console.</p>
     *
     * @param sprint The string message to be written to the file.
     */
    public static void printLine(String sprint) {
        // System.out.println(sprint);
        try {
            FileWriter myWriter = new FileWriter(fileOutput, true);
            myWriter.write(sprint + "\n");
            myWriter.close();
        } catch (IOException e) {
            System.out.println("ERROR:: writing on file: " + fileOutput);
            e.printStackTrace();
        }
    }

    /**
     * Prints the contents of a generic list of items to the output file.
     *
     * <p>This method utilizes introspection (instanceof) to determine the type of objects
     * contained in the list (Administrator, Associate, or Activity) and prints an appropriate header.</p>
     *
     * <p><b>Special Handling for Activities:</b> If the list contains {@link Activity} objects,
     * this method also iterates through and prints the names of all associates currently
     * subscribed to each activity.</p>
     *
     * @param arrayList The list of items extending the base {@link Item} class.
     * @return {@code true} if the list was processed and printed; {@code false} if the list was empty or null.
     */
    public boolean printArrayList(ArrayList<? extends Item> arrayList) {
        if (arrayList.isEmpty()) {
            printLine("WARNING:: Size of parameter: ArrayList <= 0");
            return false;
        }

        if (arrayList.get(0) instanceof Administrator) {
            printLine("---TYPE: ADMINISTRATORS---");
        } else if (arrayList.get(0) instanceof Associate) {
            printLine("---TYPE: ASSOCIATES---");
        } else if (arrayList.get(0) instanceof Activity) {
            printLine("---TYPE: ACTIVITYIES---");
        } else {
            printLine("---TYPE: UNKNOWN---");
        }

        for (int i = 0; i < arrayList.size(); i++) {
            printLine(arrayList.get(i).getDataToString());
            
            // Nested printing for activity subscribers
            if (arrayList.get(0) instanceof Activity) {
                ArrayList<Associate> associateSubscripted = ((Activity) arrayList.get(i)).getSubscribed();
                for (int j = 0; j < associateSubscripted.size(); j++) {
                    printLine(associateSubscripted.get(j).getCompleteName());
                }
            }
        }
        return true;
    }

    /**
     * Clears the content of the output log file.
     *
     * <p>This is typically called at the start of the application to ensure a clean slate
     * for the new session's logs. It overwrites the existing file with an empty state.</p>
     */
    public void resetfile() {
        try {
            FileWriter myWriter = new FileWriter(fileOutput, false);
            myWriter.close();
            printLine("Output File Setted");
        } catch (IOException e) {
            System.out.println("ERROR:: resetting file: " + fileOutput);
            e.printStackTrace();
        }
    }

    /**
     * The entry point for the logic execution of the SportCircle system.
     *
     * <p>Initializes the environment by resetting the output files.</p>
     *
     * @param args Command line arguments (currently unused).
     */
    public void main(String[] args) {
        resetfile();
    }
}