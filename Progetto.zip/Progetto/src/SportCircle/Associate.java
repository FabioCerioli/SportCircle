package SportCircle;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Represents a registered member (Associate) of the Sport Circle system.
 *
 * 
 *
 * <p>The {@code Associate} class encapsulates all personal data, contact information,
 * and security credentials for a standard user. It serves as the superclass for
 * {@link Administrator}.</p>
 *
 * <p>Key features include:</p>
 * <ul>
 * <li><b>Identity Management:</b> Unique UUID generation for new users.</li>
 * <li><b>Security:</b> Built-in password hashing using SHA-256 via {@link #hashPassword(String)}.</li>
 * <li><b>Status Tracking:</b> Management of membership status ({@link MemberStatus}) and account locking.</li>
 * </ul>
 *
 * @see Administrator
 * @see MemberStatus
 */
public class Associate extends Item {

    private String associateId;
    private String surname = "";
    private String firstName = "";
    private String emailAddress = "";
    private String hashedPassword = "";
    private int age = 0;
    private LocalDate dateOfSubscription = LocalDate.of(1, 1, 1);
    private MemberStatus status = MemberStatus.REGULAR;
    private Boolean locked = false;

    /**
     * Protected default constructor for serialization or subclass usage.
     */
    protected Associate() {
    }

    /**
     * Registers a new Associate with basic personal details.
     *
     * <p>This constructor automatically generates a new random {@link UUID} for the user.
     * The password provided is immediately hashed before storage.</p>
     *
     * @param surname           The user's last name.
     * @param firstName         The user's first name.
     * @param emailAddress      The user's email address (used for login).
     * @param plainTextPassword The raw password (will be hashed).
     */
    public Associate(String surname, String firstName, String emailAddress, String plainTextPassword) {
        setAssociateId(UUID.randomUUID().toString());
        setSurname(surname);
        setFirstName(firstName);
        setEmailAddress(emailAddress);
        setPassword(plainTextPassword);
    }

    /**
     * Registers a new Associate with age information.
     *
     * @param surname           The user's last name.
     * @param firstName         The user's first name.
     * @param emailAddress      The user's email address.
     * @param plainTextPassword The raw password.
     * @param age               The user's age.
     */
    public Associate(String surname, String firstName, String emailAddress, String plainTextPassword, int age) {
        this(surname, firstName, emailAddress, plainTextPassword);
        setAge(age);
    }

    /**
     * Reconstructs an Associate object from existing data (e.g., during database loading).
     *
     * @param associateId       The existing unique ID.
     * @param surname           The user's last name.
     * @param firstName         The user's first name.
     * @param emailAddress      The user's email address.
     * @param plainTextPassword The raw password (will be hashed).
     */
    public Associate(String associateId, String surname, String firstName, String emailAddress,
                     String plainTextPassword) {
        setAssociateId(associateId);
        setSurname(surname);
        setFirstName(firstName);
        setEmailAddress(emailAddress);
        setPassword(plainTextPassword);
    }

    /**
     * Reconstructs a fully populated Associate object with all fields.
     *
     * <p>This constructor is primarily used when deserializing data from the CSV storage,
     * ensuring all historical data (status, subscription date) is preserved.</p>
     *
     * @param associateId       The existing unique ID.
     * @param surname           The user's last name.
     * @param firstName         The user's first name.
     * @param emailAddress      The user's email address.
     * @param plainTextPassword The raw password (note: usually overwritten by setPasswordAlreadyHashed during load).
     * @param age               The user's age.
     * @param status            The string representation of the {@link MemberStatus}.
     * @param date              The subscription date in "yyyy-MM-dd" format.
     */
    public Associate(String associateId, String surname, String firstName, String emailAddress,
                     String plainTextPassword, int age, String status, String date) {
        setAssociateId(associateId);
        setStatus(status);
        setSurname(surname);
        setFirstName(firstName);
        setEmailAddress(emailAddress);
        setPassword(plainTextPassword);
        setAge(age);
        setDateOfSubscription(date);
    }

    /**
     * Gets the unique identifier of the associate.
     *
     * @return The UUID string.
     */
    public final String getAssociateId() {
        return associateId;
    }

    /**
     * Gets the associate's surname.
     *
     * @return The surname.
     */
    public final String getSurname() {
        return surname;
    }

    /**
     * Gets the associate's first name.
     *
     * @return The first name.
     */
    public final String getFirstName() {
        return firstName;
    }

    /**
     * Gets the associate's email address.
     *
     * @return The email address.
     */
    public final String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Gets the associate's age.
     *
     * @return The age in years.
     */
    public final int getAge() {
        return age;
    }

    /**
     * Gets the secure hash of the associate's password.
     *
     * @return The SHA-256 hashed string.
     */
    public final String getHashedPassword() {
        return hashedPassword;
    }

    /**
     * Gets the current membership status.
     *
     * @return The {@link MemberStatus} enum.
     */
    public MemberStatus getStatus() {
        return status;
    }

    /**
     * Gets the string representation of the membership status.
     *
     * @return The status name.
     */
    public String getStatusToString() {
        return status.toString();
    }

    /**
     * Gets the date of subscription as a string.
     *
     * @return The date in "yyyy-MM-dd" format.
     */
    public String getDateOfSubscription() {
        return dateOfSubscription.toString();
    }

    /**
     * Checks if the account is currently locked.
     *
     * @return {@code true} if locked, {@code false} otherwise.
     */
    public Boolean isLocked() {
        return locked;
    }

    /**
     * Sets the unique identifier for the associate.
     *
     * @param associateId The UUID string.
     */
    public final void setAssociateId(String associateId) {
        this.associateId = associateId;
    }

    /**
     * Sets the associate's surname.
     *
     * @param surname The surname.
     */
    public final void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * Sets the associate's first name.
     *
     * @param firstName The first name.
     */
    public final void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Sets the associate's email address.
     *
     * @param emailAddress The email address.
     */
    public final void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * Sets the associate's age.
     *
     * @param age The age.
     */
    public final void setAge(int age) {
        this.age = age;
    }

    /**
     * Locks the associate's account, preventing login.
     */
    public void addLock() {
        this.locked = true;
    }

    /**
     * Unlocks the associate's account, allowing login.
     */
    public void removeLock() {
        this.locked = false;
    }

    /**
     * Updates the membership status from a string value.
     *
     * <p>If the provided string does not match any {@link MemberStatus}, the status
     * defaults to {@code REGULAR}.</p>
     *
     * @param statusStr The string representation of the status (case-insensitive).
     */
    public void setStatus(String statusStr) {
        if (statusStr == null) return;
        try {
            this.status = MemberStatus.valueOf(statusStr.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            this.status = MemberStatus.REGULAR;
        }
    }

    /**
     * Sets the subscription date from a string.
     *
     * @param dateString The date in "yyyy-MM-dd" format.
     */
    public void setDateOfSubscription(String dateString) {
        this.dateOfSubscription = LocalDate.parse(dateString);
    }

    /**
     * Hashes the provided plain text password and updates the stored credentials.
     *
     * @param plainTextPassword The new password in plain text.
     */
    public final void setPassword(String plainTextPassword) {
        this.hashedPassword = hashPassword(plainTextPassword);
    }

    /**
     * Sets the hashed password directly.
     *
     * <p><b>Note:</b> This is strictly for loading pre-existing data (e.g., from CSV)
     * where the password is already encrypted.</p>
     *
     * @param hashedPassword The SHA-256 hash string.
     */
    public final void setPasswordAlreadyHashed(String hashedPassword) {
        this.hashedPassword = hashedPassword;
    }

    /**
     * Generates a SHA-256 hash for the given plain text password.
     *
     * @param plainTextPassword The password to hash.
     * @return The hexadecimal string representation of the hash, or {@code null} if the algorithm is unavailable.
     */
    public static String hashPassword(String plainTextPassword) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = messageDigest.digest(plainTextPassword.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Verifies if a provided plain text password matches the stored hash.
     *
     * @param plainTextPassword The password input to verify.
     * @return {@code true} if the password matches, {@code false} otherwise.
     */
    public boolean verifyPassword(String plainTextPassword) {
        return hashedPassword.equals(hashPassword(plainTextPassword));
    }

    /**
     * Returns the full name of the associate.
     *
     * @return A string in the format "Surname FirstName".
     */
    public final String getCompleteName() {
        return getSurname() + " " + getFirstName();
    }

    /**
     * Returns a concise string representation of the associate's basic data.
     *
     * @return A string containing "Surname FirstName Email".
     */
    public String getDataToString() {
        return surname + " " + firstName + " " + emailAddress;
    }

    /**
     * Returns a detailed string representation for debugging purposes.
     *
     * <p><b>Security Warning:</b> This includes the hashed password.</p>
     *
     * @return A colon-separated string of user details.
     */
    public String getDebugString() {
        return surname + ":" + firstName + ":" + emailAddress + ":" + hashedPassword;
    }

    /**
     * Returns a string representation of the object suitable for UI display.
     *
     * @return A string in the format "Surname FirstName (Email)".
     */
    @Override
    public String toString() {
        return getSurname() + " " + getFirstName() + " (" + getEmailAddress() + ")";
    }
}