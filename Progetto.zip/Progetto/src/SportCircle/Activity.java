package SportCircle;

import java.util.ArrayList;

/**
 * Represents a scheduled sporting event or session that {@link Associate} members can join.
 *
 * 
 *
 * <p>This class encapsulates all the details regarding a specific event, including:</p>
 * <ul>
 * <li><b>Metadata:</b> Name, Date, Time.</li>
 * <li><b>Categorization:</b> The specific {@link SportType} (e.g., Tennis) and {@link ActivityType} (e.g., Match).</li>
 * <li><b>Participation:</b> A list of currently subscribed associates.</li>
 * </ul>
 *
 * <p>It provides logic to prevent duplicate subscriptions and helper methods to parse
 * configuration strings into domain Enums.</p>
 *
 * @see Associate
 * @see SportType
 * @see ActivityType
 */
public class Activity extends Item {

    /** The display name or title of the activity. */
    private String activityName = "";

    /** The format category of the activity (e.g., TOURNAMENT, LESSON). */
    private ActivityType activityType = ActivityType.NULL;

    /** The specific sport discipline involved. */
    private SportType sportType = SportType.NULL;

    /** The date of the event (typically in YYYY-MM-DD format). */
    private String activityDate;

    /** The start time of the event (typically in HH:MM format). */
    private String activityTime;

    /** Internal counter for the number of participants. */
    private int subscribedCount = 0;

    /** The list of members currently enrolled in this activity. */
    private ArrayList<Associate> subscribedAssociates = new ArrayList<>();

    /**
     * Constructs a new Activity using strongly-typed Enum parameters.
     *
     * @param activityName The title of the activity.
     * @param sportType    The {@link SportType} enum value.
     * @param activityType The {@link ActivityType} enum value.
     * @param date         The date string.
     * @param time         The time string.
     */
    public Activity(String activityName, SportType sportType, ActivityType activityType, String date, String time) {
        setActivityName(activityName);
        setSportType(sportType);
        setActivityType(activityType);
        setActivityDate(date);
        setActivityTime(time);
    }

    /**
     * Constructs a new Activity by parsing string representations of the types.
     *
     * <p>This constructor attempts to convert the provided strings into their corresponding
     * Enum constants. If parsing fails, an error is logged to {@code System.err}.</p>
     *
     * @param activityName        The title of the activity.
     * @param sportTypeString     The string representation of the sport (case-insensitive).
     * @param activityTypeString  The string representation of the activity type (case-insensitive).
     * @param date                The date string.
     * @param time                The time string.
     */
    public Activity(String activityName, String sportTypeString, String activityTypeString, String date, String time) {
        try {
            SportType sportType = SportType.valueOf(sportTypeString.trim().toUpperCase());
            ActivityType activityType = ActivityType.valueOf(activityTypeString.trim().toUpperCase());

            setActivityName(activityName);
            setSportType(sportType);
            setActivityType(activityType);
            setActivityDate(date);
            setActivityTime(time);

        } catch (IllegalArgumentException e) {
            System.err.println("❌ Error: Invalid sport/activity type: " + sportTypeString + ", " + activityTypeString);
        }
    }

    /**
     * Gets the name of the activity.
     *
     * @return The activity name.
     */
    public String getActivityName() {
        return activityName;
    }

    /**
     * Sets the name of the activity.
     *
     * @param activityName The new name.
     */
    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    /**
     * Gets the category type of the activity.
     *
     * @return The {@link ActivityType}.
     */
    public ActivityType getActivityType() {
        return activityType;
    }

    /**
     * Sets the category type of the activity.
     *
     * @param activityType The new {@link ActivityType}.
     */
    public void setActivityType(ActivityType activityType) {
        this.activityType = activityType;
    }

    /**
     * Gets the sport associated with this activity.
     *
     * @return The {@link SportType}.
     */
    public SportType getSportType() {
        return sportType;
    }

    /**
     * Sets the sport associated with this activity.
     *
     * @param sportType The new {@link SportType}.
     */
    public void setSportType(SportType sportType) {
        this.sportType = sportType;
    }

    /**
     * Gets the date of the activity.
     *
     * @return The date string.
     */
    public String getActivityDate() {
        return activityDate;
    }

    /**
     * Sets the date of the activity.
     *
     * @param activityDate The new date string.
     */
    public void setActivityDate(String activityDate) {
        this.activityDate = activityDate;
    }

    /**
     * Gets the scheduled time of the activity.
     *
     * @return The time string.
     */
    public String getActivityTime() {
        return activityTime;
    }

    /**
     * Sets the scheduled time of the activity.
     *
     * @param activityTime The new time string.
     */
    public void setActivityTime(String activityTime) {
        this.activityTime = activityTime;
    }

    /**
     * Returns a concise string representation of the activity's classification.
     *
     * @return A string in the format "SportType ActivityType" (e.g., "TENNIS MATCH").
     */
    public String getDataToString() {
        return sportType + " " + activityType;
    }

    /**
     * Returns a debug-friendly string representation.
     *
     * @return A string in the format "SportType:ActivityType".
     */
    public String getDebugString() {
        return sportType + ":" + activityType;
    }

    /**
     * Retrieves a list of all associates currently subscribed to this activity.
     *
     * <p>Returns a <b>copy</b> of the internal list to prevent external modification
     * of the underlying data structure.</p>
     *
     * @return A new {@code ArrayList} containing the subscribed {@link Associate} objects.
     */
    public ArrayList<Associate> getSubscribed() {
        return new ArrayList<>(subscribedAssociates);
    }

    /**
     * Attempts to subscribe an associate to this activity.
     *
     * <p>The subscription is rejected if the associate is null or already subscribed.</p>
     *
     * @param associate The associate to subscribe.
     * @return {@code true} if the subscription was successful, {@code false} if already subscribed.
     */
    public boolean subscribeAssociate(Associate associate) {
        if (associate != null && !subscribedAssociates.contains(associate)) {
            subscribedAssociates.add(associate);
            subscribedCount++;
            return true;
        }
        return false;
    }

    /**
     * Unsubscribes an associate from this activity.
     *
     * @param associate The associate to remove.
     * @return {@code true} if the associate was found and removed, {@code false} otherwise.
     */
    public boolean unsubscribeAssociate(Associate associate) {
        if (subscribedAssociates.remove(associate)) {
            subscribedCount--;
            return true;
        }
        return false;
    }

    /**
     * Updates the activity type by parsing a string value.
     *
     * <p>Catches {@link IllegalArgumentException} and logs an error if the string
     * does not match any value in {@link ActivityType}.</p>
     *
     * @param activityTypeString The string representation of the new activity type.
     */
    public void setActivityType(String activityTypeString) {
        try {
            ActivityType parsed = ActivityType.valueOf(activityTypeString.trim().toUpperCase());
            setActivityType(parsed);
        } catch (IllegalArgumentException e) {
            System.err.println("❌ Error: Invalid activityType: " + activityTypeString);
        }
    }

    /**
     * Updates the sport type by parsing a string value.
     *
     * <p>Catches {@link IllegalArgumentException} and logs an error if the string
     * does not match any value in {@link SportType}.</p>
     *
     * @param sportTypeString The string representation of the new sport type.
     */
    public void setSportType(String sportTypeString) {
        try {
            SportType parsed = SportType.valueOf(sportTypeString.trim().toUpperCase());
            setSportType(parsed);
        } catch (IllegalArgumentException e) {
            System.err.println("❌ Error: Invalid sportType: " + sportTypeString);
        }
    }

    /**
     * Gets the total number of subscribed associates.
     *
     * @return The count of participants.
     */
    public int getSubscribedCount() {
        return subscribedCount;
    }

    /**
     * Manually sets the subscriber count.
     *
     * <p><b>Note:</b> This is primarily used when loading statistics from persistence files
     * where the actual Associate objects might not be fully linked yet.</p>
     *
     * @param subscribedCount The new count.
     */
    public void setSubscribedCount(int subscribedCount) {
        this.subscribedCount = subscribedCount;
    }
}