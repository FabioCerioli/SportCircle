package SportCircle;

/**
 * Defines the comprehensive list of sports disciplines supported by the SportCircle application.
 *
 * 

[Image of sports categories icons]

 *
 * <p>This enumeration is utilized throughout the system to:</p>
 * <ul>
 * <li>Categorize {@link Activity} instances.</li>
 * <li>Filter search results in the {@code ActivitiesView}.</li>
 * <li>Generate statistical reports in the {@code ActivityRecommender}.</li>
 * </ul>
 *
 * <p>It covers a wide range of categories including team sports, racket sports,
 * water sports, martial arts, fitness activities, and mental sports.</p>
 *
 * @see Activity
 */
public enum SportType {
    FOOTBALL,
    FUTSAL,
    BASKETBALL,
    VOLLEYBALL,
    BEACH_VOLLEY,
    BASEBALL,
    SOFTBALL,
    RUGBY,
    HOCKEY,
    ICE_HOCKEY,
    HANDBALL,
    WATER_POLO,
    CRICKET,
    LACROSSE,
    TENNIS,
    TABLE_TENNIS,
    BADMINTON,
    SQUASH,
    SWIMMING,
    RUNNING,
    MARATHON,
    CYCLING,
    MOUNTAIN_BIKE,
    TRIATHLON,
    BOXING,
    KICKBOXING,
    MARTIAL_ARTS,
    JUDO,
    KARATE,
    TAEKWONDO,
    WRESTLING,
    FENCING,
    ARCHERY,
    CLIMBING,
    BOULDERING,
    SKIING,
    SNOWBOARDING,
    SKATEBOARDING,
    SURFING,
    WINDSURF,
    KITESURF,
    ROWING,
    KAYAKING,
    CANOEING,
    SAILING,
    DIVING,
    GYMNASTICS,
    YOGA,
    PILATES,
    CROSSFIT,
    BODYBUILDING,
    AEROBICS,
    DANCE,
    ZUMBA,
    PARKOUR,
    CALISTHENICS,
    CHESS,
    ESPORTS,
    DARTS,
    BOWLING,
    SHOOTING,
    GOLF,
    BILLIARDS,

    /**
     * Represents a sport or physical activity not explicitly defined in the standard list.
     */
    OTHER,

    /**
     * Represents an undefined, uninitialized, or invalid sport type.
     * Used primarily for error handling or default initialization.
     */
    NULL
}