package SportCircle;

/**
 * Defines the hierarchy of membership tiers available to {@link Associate} members.
 *
 * 
 *
 * <p>This enumeration is used to categorize users based on their subscription level or loyalty status.
 * In the User Interface ({@code ProfileView}, {@code MembersView}), these statuses are typically
 * represented by specific color codes determined by {@code UiUtils}:</p>
 * <ul>
 * <li><b>REGULAR:</b> Standard level (Default).</li>
 * <li><b>SILVER:</b> First premium tier.</li>
 * <li><b>GOLD:</b> Intermediate premium tier.</li>
 * <li><b>PLATINUM:</b> High-level tier.</li>
 * <li><b>DIAMOND:</b> Exclusive top-level tier.</li>
 * </ul>
 *
 * @see Associate
 * @see application.UiUtils
 */
public enum MemberStatus {

    /**
     * The standard entry-level membership status assigned to new users by default.
     */
    REGULAR,

    /**
     * The first tier of premium membership.
     */
    SILVER,

    /**
     * A mid-tier premium membership offering increased benefits.
     */
    GOLD,

    /**
     * A high-tier membership status for long-standing or premium members.
     */
    PLATINUM,

    /**
     * The highest and most exclusive membership tier available in the system.
     */
    DIAMOND
}